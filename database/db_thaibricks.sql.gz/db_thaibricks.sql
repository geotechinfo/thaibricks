-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2015 at 09:53 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_thaibricks`
--

-- --------------------------------------------------------

--
-- Table structure for table `ac_packages`
--

CREATE TABLE IF NOT EXISTS `ac_packages` (
`package_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ac_packages`
--

INSERT INTO `ac_packages` (`package_id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Plain Listing(Free)', 0, 0),
(2, 'Paid Listing', 0, 0),
(3, 'Advertiser', 0, 0),
(4, 'Featured Listing', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ac_permissions`
--

CREATE TABLE IF NOT EXISTS `ac_permissions` (
`permission_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ac_permissions`
--

INSERT INTO `ac_permissions` (`permission_id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'property_posting', 0, 0),
(2, 'property_contact', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ac_roles`
--

CREATE TABLE IF NOT EXISTS `ac_roles` (
`role_id` int(11) NOT NULL,
  `title` varchar(25) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ac_roles`
--

INSERT INTO `ac_roles` (`role_id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Seller', 0, 0),
(2, 'Buyer', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ac_role_permissions`
--

CREATE TABLE IF NOT EXISTS `ac_role_permissions` (
`role_permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ac_role_permissions`
--

INSERT INTO `ac_role_permissions` (`role_permission_id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, 0),
(2, 1, 2, 0, 0),
(3, 2, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ac_users`
--

CREATE TABLE IF NOT EXISTS `ac_users` (
`user_id` int(11) NOT NULL,
  `user_code` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `location` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `email_code` int(10) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `phone_code` int(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `profile_image` varchar(100) NOT NULL,
  `banner_image` varchar(100) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `status` smallint(1) NOT NULL DEFAULT '1' COMMENT '0->Inactive,1->Active',
  `is_featured` smallint(1) NOT NULL DEFAULT '0' COMMENT '1->Featured',
  `is_email_verified` smallint(1) NOT NULL DEFAULT '0' COMMENT '0->No,1->Yes',
  `reset_code` varchar(10) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `ac_users`
--

INSERT INTO `ac_users` (`user_id`, `user_code`, `first_name`, `last_name`, `description`, `location`, `email`, `email_code`, `phone`, `phone_code`, `password`, `remember_token`, `profile_image`, `banner_image`, `logo`, `status`, `is_featured`, `is_email_verified`, `reset_code`, `created_at`, `updated_at`) VALUES
(1, 'AGN15455678', 'NK', 'Relators', '', 1, 'pioneer.properties@gmail.com', 0, '1234567890', 0, '$2y$10$Ihj7BF8xxE0.1AN6DmfdceAPOheT1B3IfLi0vy0Ub.Two4qWBF222', 'eJCJUPUqY8IZsJjyIigjpnEzap6g4M8buJHHQ8FHC6xp1ZMJ7El6urVzGjJp', '4520394197.jpg', '2555408949.jpg', '', 1, 1, 0, '', 1, 2015),
(2, 'AGN15487623', 'Sandip', 'Roy', '', 4, 'sandip01@gmail.com', 0, '8989898', 0, '$2y$10$INA/ZBpAPYBXbYDfGZ.93evQPDI6i4LEYyh.VI58gWvgiLNBuB/Sq', '6mEpP8FZKDnFsBvq24ES9m6wFRpxUEnSZicHRAKBRCCJA1Ypn3rvTqX2mzSv', '8731210856.jpg', '3572898962.jpg', '', 1, 0, 0, '', 1, 2015),
(3, 'AGN1571080', 'Nithi', 'Ch', '', 4, 'tanwita@gmail.com', 0, '56456456', 0, '$2y$10$BUgizuodxeCZNAvjYLlty.1r9YaVltHLxs1dLSQKMOadsQTLowVwe', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(4, 'AGN15892530', 'Santanu', 'Jana', '', 4, 'santanujanagipl@yopmail.com', 0, '882099209', 0, '$2y$10$sDmshpdOllXPWbvQxueoCeCnDRJUgFfMsDU8IBNj7PErFhAScD0pO', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(5, 'AGN15249412', 'aaa', 'aa', '', 4, 'nithizz@gmail.com', 0, '666666', 0, '$2y$10$eleYZCspMJhnOcUJxTNVz.7OXlwa5lbQbTQ4YEJdzTK0sCMUlCkly', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(6, 'AGN15569468', 'aaa', 'aa', '', 4, 'lol@gmail.com', 0, '666666111111', 0, '$2y$10$ZV6qS66OmzQBFU3pKFR/yOaCies4u4qsbbdUwZwhao8.lKYIR/01O', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(7, 'AGN1599103', 'Ridin', 'Dinesh', '', 4, 'ridindinesh@gmail.com', 0, '894503647', 0, '$2y$10$c7KD4bPKkSzo1lAeoAQf4.1fnfWX5UkbAG0naSljGYyT1Y4bXU9hO', 'WQGAmQC4NEfhfXbRFK4r1Zy6zzduO8Rwb2xyQ6gUQT1KK2OlhjTeTNgIEjlR', '', '', '', 1, 0, 0, '', 1, 2015),
(8, 'AGN15787115', 'debasmita', 'dutta', '', 4, '1234@geotechinfo.net', 0, '124356788', 0, '$2y$10$BfvLi/G5730T4.4tFzeqtem5sA.R4D3qFFCP.cVn0mhe5AqpwuD0a', 'AEJN7qSSywtkYQNHvhRKTgUL2oJa4zcPyXQTPv4uVwo3WlvkNvJxz0y4Jy8T', '', '', '', 1, 0, 0, '', 1, 2015),
(9, 'AGN15638262', 'Debasmita', 'Dutta', '', 1, '12345@gmail.com', 0, '987654321', 0, '$2y$10$RH4VKxg3iGpSezk6dMzjHO03BKbJ7ESsnFenkACfU8J5i0XmXu.sq', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(10, 'AGN15829968', 'Debasmita', 'Dutta', '', 1, 'abcd@yopmail.com', 0, '9876543215', 0, '$2y$10$32zgp/w6iKbbZY5tFSQv3.HATfo6RO6vbmEfJBUnfMU1k4T2HPLNC', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(11, 'AGN15235052', 'Debasmita', 'Dutta', '', 1, 'abcde@yopmail.com', 0, '42353262363', 0, '$2y$10$Red/dprhCJfrdAXvqNyEs.0SqTXps0/AOf9oQjS4OMR05oGZhuevi', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(12, 'AGN15685358', 'Debasmita', 'Dutta', '', 1, 'abcdef@yopmail.com', 0, '325326236', 0, '$2y$10$TLwJWI017TRbVglvCpMfyuQOpC0hBMLbWwpJfcRKwm7Y7YwFoqnbO', 'kI2wN6jFI3EqCJO7pMcrtJwZ1rp8QsiwW6IgHamx7Ck8Us9va8ekFGmjsGsU', '', '', '', 1, 0, 0, '', 1, 2015),
(13, 'AGN15721631', 'Debasmita', 'Dutta', '', 1, 'debasmita.dutta@geotechinfo.net', 0, '432523632626', 0, '$2y$10$MemmR1IJV9qW5LPY4XkIeOLutn1qN9vOEiax0G1w.r6jIEX8ICTQy', 'pd2ElIIW6h0t9HzUGek52nToQ3j8gZy5b0OUjGxvYyEqvMM9b5PR6uBFECrA', '', '', '', 1, 0, 0, '', 1, 2015),
(14, 'AGN15552085', 'Pratheep', 'Sethi', '', 1, 'pratheeps.sethi@gmail.com', 0, '850675114', 0, '$2y$10$syUYTdn201AIZv0c.w.cOe8gVENWUlCFbvHmOxbZaVtmSKmoX9h6W', NULL, '', '', '', 1, 0, 0, '', 1, 2015),
(15, 'AGN15870230', 'Ridin', 'Dinesh', '', 1, 'ridindinesh@yahoo.com', 0, '894503646', 0, '$2y$10$doJJOhWHODGQNNpA/.TlHeANUvDlkj9i6VW4/U2SkUyvaQPrnqaKG', 'sukogcaoU9cT9c3434Fut3AkNvEhODuIqulI9gYn1CWPFXAy3tVjlboEXhNr', '3133892876.jpg', '', '', 1, 0, 0, '', 2015, 2015),
(16, 'AGN16478807', 'Ridin', 'Dinesh', '', 1, 'ridindinesh@yahoo1.com', 0, '897545844', 0, '$2y$10$Z29zSo7TCVy0tx/ME55UHe40Vz8LxuPiWzOghp9a.n4tgSNkUU7oC', 'hMnLrG0rH4FZupiqFTQUPxoPKJqGhAwAWxv7qF18cEuNVJ0lcf7uAiqNIyUT', '', '', '', 1, 0, 0, '', 2015, 2015),
(17, 'AGN17632540', 'Ridin', 'Dinesh', '', 4, 'ridindinesh@builder.com', 0, '5646546546', 0, '$2y$10$jD52oSANDh1/6DF.Q17aXuLOlGY1m3EzCk3lC95Ll7Y7V1Ljiz7tq', NULL, '', '', '', 1, 0, 0, '', 2015, 2015),
(18, 'AGN18445951', 'Nithi', 'C.', '', 1, 'nchansrichawla@gmail.com', 0, '812862323', 0, '$2y$10$zCYs.0q.FZc8Bbbqzyiope4hg/3zVwRdk3sFcEExAdVMT5ld.5xYS', NULL, '', '', '', 1, 0, 0, '', 2015, 2015),
(19, 'AGN19659132', 'Swadeep', 'Chansrichavala', '', 1, 'schansrichavala@gmail.com', 0, '811161100', 0, '$2y$10$sDJEtaATlKA/mkqq4rHvNe.fNFjSycSIWEW.E1Zh8HRnxP69SJBEK', NULL, '', '', '', 1, 1, 0, '', 2015, 2015),
(20, 'AGN20223268', 'Ayan', 'Bhattacharyya', 'Description about Ayan Bhattacharyya s Thaibricks property seller.', 4, 'neelanjan.basu@geotechinfo.net', 0, '9903717914', 0, '$2y$10$DQ2H04OMC9cO4HMBL9nh8eL5/pxxvwiwLOWbIFOIlLBj1qWbRXzEO', 'nL6SAqbynK6Qzl7jkgFSB5uuJw9XTxJYybwdW3LtSTXtfkN98Olcjrz5sTGk', '', '', '', 0, 1, 0, '871205', 2015, 2015),
(21, 'AGN21732664', 'Neelanjan', 'Basu', ' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio. Duis est nisl, finibus consequat cursus in, hendrerit in leo. Praesent sed ullamcorper justo. Morbi sagittis vehicula eros, ut fermentum risus varius sit amet. Integer purus ligula, egestas in sagittis quis, vehicula at tellus. Pellentesque mattis consequat ex, nec bibendum tellus varius eu. Vivamus ac ex orci.\r\n\r\nCurabitur aliquet leo quis sodales dapibus. Fusce neque lacus, condimentum sit amet porta vel, euismod id eros. Fusce nec volutpat dui, non dapibus ipsum. Curabitur venenatis tincidunt diam, ac blandit lectus vehicula ut. Fusce commodo suscipit laoreet. Nam gravida justo lorem, eget rutrum nibh pulvinar ut. Pellentesque commodo condimentum nisl, vitae vestibulum mauris egestas in. Pellentesque elementum eu elit vitae pretium. Donec a vehicula lorem, et sodales libero. Proin id tincidunt sapien, ac finibus eros. Etiam quis sapien eu nisl tristique lacinia. Nulla aliquet interdum purus sed accumsan. Pellentesque faucibus ante condimentum lorem ornare, ac eleifend arcu lobortis. Maecenas vehicula varius metus, a gravida libero congue ac. Suspendisse potenti. Ut non congue lectus.\r\n\r\nPhasellus mattis vehicula ex, et cursus nibh feugiat sed. Duis id enim est. Nam venenatis cursus metus, ut vulputate nunc vestibulum sit amet. Vivamus vel lacinia dui. Donec eleifend eleifend est in auctor. Suspendisse vel magna massa. Duis malesuada sit amet dolor sit amet sodales. ', 48, 'nbbabibasu5@gmail.com', 0, '9903717917', 0, '$2y$10$MFXQ0lx5/lr5Iorm1WVeG.sEkI611d7NY6BVzgzOEOYjt34SMAkQq', '6KqdVbqPyOpoyidZVnPr6TA81c9ZAyIVb63r6xyq7NocnM82Nxlvp96EQZka', 'profile_21.png', 'banner_21.png', '', 1, 1, 1, '', 2015, 2015),
(22, 'AGN22615487', 'Neelanjan', 'Basu', 'Description about this agent.', 48, 'neelbnbasu@gmail.com', 0, '9903717919', 0, '$2y$10$xnr20mAotl8Yd4EjObRVI.U17oqZOD9pFclXaTlV.D.cnxaAt3Zke', 'qPDZsh6RH7w0QPTtIAqcgX3eXZM2rXOpHUOJPxS0berkX9dsggVKLy80qEmk', '', '', '', 1, 1, 1, '', 2015, 2015),
(23, 'AGN23674850', 'Tanwita ', 'Roy', 'This is a test seller account', 43, 'sanjibtefl@gmail.com', 0, '12345677', 0, '$2y$10$kdi.PNz6Rk6RBoW9hzkau.Dow0W8qDcKkm7.znvWDpggCQvON9ZuS', NULL, '', '', '', 1, 0, 1, '', 2015, 2015);

--
-- Triggers `ac_users`
--
DELIMITER //
CREATE TRIGGER `trg_bi_users` BEFORE INSERT ON `ac_users`
 FOR EACH ROW BEGIN DECLARE SPV_R INT(5); DECLARE SPV_MAX_ID INT(11); SET SPV_MAX_ID = (SELECT MAX(user_id) FROM ac_users)+1; SET SPV_R = RAND()*1000000; SET NEW.user_code = CONCAT('AGN',SPV_MAX_ID,SPV_R); END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ac_user_packages`
--

CREATE TABLE IF NOT EXISTS `ac_user_packages` (
`user_package_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ac_user_roles`
--

CREATE TABLE IF NOT EXISTS `ac_user_roles` (
`user_role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ad_advertisements`
--

CREATE TABLE IF NOT EXISTS `ad_advertisements` (
`advertisement_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `ad_package_id` int(11) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `grace_period` int(11) NOT NULL,
  `type` smallint(1) NOT NULL COMMENT '1->Property Code, 2->External Link,3->Google Ad Sence',
  `ad_status` smallint(1) NOT NULL DEFAULT '1' COMMENT '1->Active,0->Inactive',
  `property_id` int(11) DEFAULT '0',
  `external_link` text,
  `google_ads` text
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `ad_advertisements`
--

INSERT INTO `ad_advertisements` (`advertisement_id`, `admin_id`, `ad_package_id`, `image_file`, `description`, `start_date`, `end_date`, `grace_period`, `type`, `ad_status`, `property_id`, `external_link`, `google_ads`) VALUES
(30, 0, 1, '1429187077.png', 'a:2:{s:7:"caption";s:14:"BKK Properties";s:9:"info_line";s:73:"2 BHK multistorey apartment with attached bathroom is available for sale.";}', '2015-04-16', '2015-07-14', 10, 1, 0, 16, '', ''),
(31, 0, 2, '1429187180.png', 'a:2:{s:7:"caption";s:16:"BKK Properties 4";s:9:"info_line";s:73:"4 BHK multistorey apartment with attached bathroom is available for sale.";}', '2015-04-16', '2015-07-14', 10, 1, 0, 12, '', ''),
(32, 0, 3, '1429187267.png', 'a:2:{s:7:"caption";s:16:"BKK Properties 5";s:9:"info_line";s:73:"5 BHK multistorey apartment with attached bathroom is available for sale.";}', '2015-04-16', '2015-07-14', 10, 1, 0, 13, '', ''),
(33, 0, 11, '1429187326.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 1, 0, 17, '', ''),
(34, 0, 21, '1429187377.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 1, 0, 9, '', ''),
(35, 0, 31, '1429187425.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 2, 0, 0, 'http://google.com', ''),
(36, 0, 41, '1429187475.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 1, 0, 9, '', ''),
(37, 0, 12, '1429187508.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 2, 0, 0, 'http://yahoo.co.in', ''),
(38, 0, 22, '1429187557.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-16', '2015-06-05', 5, 1, 0, 16, '', ''),
(39, 0, 10, '1429265311.png', 'a:2:{s:7:"caption";s:30:"Premium Banner ad for Chonburi";s:9:"info_line";s:110:"This is the description for this ad. Please click on the link to go to the relevant property linked to this ad";}', '2015-04-17', '2015-07-15', 10, 1, 0, 32, '', ''),
(40, 0, 20, '1429265421.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-06-06', 5, 2, 1, 0, 'http://www.google.com', ''),
(41, 0, 30, '1429265475.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-06-06', 5, 1, 1, 31, '', ''),
(42, 0, 40, '1429265672.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-06-06', 5, 1, 1, 30, '', ''),
(43, 0, 50, '1429265707.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-06-06', 5, 1, 1, 32, '', ''),
(44, 0, 59, '1429266924.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-05-16', 3, 2, 1, 0, 'http://www.google.com', ''),
(45, 0, 59, '1429267051.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-05-16', 3, 1, 1, 32, '', ''),
(46, 0, 59, '1429267187.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-05-16', 3, 1, 1, 31, '', ''),
(47, 0, 59, '1429267249.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-05-16', 3, 1, 1, 30, '', ''),
(48, 0, 59, '1429267318.png', 'a:2:{s:7:"caption";s:0:"";s:9:"info_line";s:0:"";}', '2015-04-17', '2015-05-16', 3, 2, 1, 0, 'http://www.google.com', ''),
(49, 0, 0, '1429354834.png', 'a:2:{s:7:"caption";s:20:"Worldwide Properties";s:9:"info_line";s:110:"WorldProperties, Inc. a self-administered and self-managed real estate investment trust (REIT), is one of the ";}', '2015-04-18', '2015-07-16', 10, 2, 0, 0, 'http://www.geotechinfo.net/thaibricks/public', ''),
(50, 0, 1, '1429382175.png', 'a:2:{s:7:"caption";s:14:"BKK Properties";s:9:"info_line";s:73:"2 BHK multistorey apartment with attached bathroom is available for sale.";}', '2015-04-19', '2015-07-17', 10, 1, 0, 16, '', ''),
(51, 0, 1, '1429382341.png', 'a:2:{s:7:"caption";s:14:"BKK Properties";s:9:"info_line";s:73:"4 BHK multistorey apartment with attached bathroom is available for sale.";}', '2015-04-19', '2015-07-17', 10, 1, 0, 12, '', ''),
(52, 0, 1, '1429385179.png', 'a:2:{s:7:"caption";s:35:"This is Premium Banner for Thailand";s:9:"info_line";s:57:"Please click on More to view the related property details";}', '2015-04-19', '2015-07-17', 10, 1, 1, 32, '', ''),
(53, 0, 2, '1429385703.png', 'a:2:{s:7:"caption";s:43:"This is Premium Banner for Bangkok location";s:9:"info_line";s:49:"Please click on More to see the relevant property";}', '2015-04-19', '2015-07-17', 10, 1, 1, 13, '', ''),
(54, 0, 10, '1429442210.png', 'a:2:{s:7:"caption";s:44:"This is Premium Banner for Chonburi location";s:9:"info_line";s:49:"Please click on More to see the relevant property";}', '2015-04-19', '2015-07-17', 10, 1, 1, 31, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ad_packages`
--

CREATE TABLE IF NOT EXISTS `ad_packages` (
`ad_package_id` int(11) NOT NULL,
  `ad_type` smallint(1) NOT NULL COMMENT '1->Premium Banner,2->Featured Banner,3->Box Pannel',
  `location_id` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `grace_period` int(11) NOT NULL,
  `price` double(12,2) NOT NULL,
  `pkg_status` smallint(1) NOT NULL DEFAULT '0' COMMENT '1->Active,0->Inactive',
  `image_height` int(11) NOT NULL DEFAULT '0',
  `image_width` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `ad_packages`
--

INSERT INTO `ad_packages` (`ad_package_id`, `ad_type`, `location_id`, `duration`, `grace_period`, `price`, `pkg_status`, `image_height`, `image_width`) VALUES
(1, 1, 0, 90, 10, 1000.00, 1, 527, 1349),
(2, 1, 1, 90, 10, 1000.00, 1, 527, 1349),
(3, 1, 4, 90, 10, 1000.00, 0, 527, 1349),
(4, 1, 25, 90, 10, 1000.00, 0, 527, 1349),
(5, 1, 26, 90, 10, 1000.00, 0, 527, 1349),
(6, 1, 42, 90, 10, 1000.00, 0, 527, 1349),
(7, 1, 43, 90, 10, 1000.00, 0, 527, 1349),
(8, 1, 44, 90, 10, 1000.00, 0, 527, 1349),
(9, 1, 45, 90, 10, 1000.00, 0, 527, 1349),
(10, 1, 48, 90, 10, 1000.00, 1, 527, 1349),
(11, 2, 0, 50, 5, 750.00, 0, 143, 1012),
(12, 2, 1, 50, 5, 750.00, 0, 143, 1012),
(13, 2, 4, 50, 5, 750.00, 0, 143, 1012),
(14, 2, 25, 50, 5, 750.00, 0, 143, 1012),
(15, 2, 26, 50, 5, 750.00, 0, 143, 1012),
(16, 2, 42, 50, 5, 750.00, 0, 143, 1012),
(17, 2, 43, 50, 5, 750.00, 0, 143, 1012),
(18, 2, 44, 50, 5, 750.00, 0, 143, 1012),
(19, 2, 45, 50, 5, 750.00, 0, 143, 1012),
(20, 2, 48, 50, 5, 750.00, 1, 143, 1012),
(21, 3, 0, 50, 5, 750.00, 0, 143, 1012),
(22, 3, 1, 50, 5, 750.00, 0, 143, 1012),
(23, 3, 4, 50, 5, 750.00, 0, 143, 1012),
(24, 3, 25, 50, 5, 750.00, 0, 143, 1012),
(25, 3, 26, 50, 5, 750.00, 0, 143, 1012),
(26, 3, 42, 50, 5, 750.00, 0, 143, 1012),
(27, 3, 43, 50, 5, 750.00, 0, 143, 1012),
(28, 3, 44, 50, 5, 750.00, 0, 143, 1012),
(29, 3, 45, 50, 5, 750.00, 0, 143, 1012),
(30, 3, 48, 50, 5, 750.00, 1, 143, 1012),
(31, 4, 0, 50, 5, 750.00, 0, 143, 1012),
(32, 4, 1, 50, 5, 750.00, 0, 143, 1012),
(33, 4, 4, 50, 5, 750.00, 0, 143, 1012),
(34, 4, 25, 50, 5, 750.00, 0, 143, 1012),
(35, 4, 26, 50, 5, 750.00, 0, 143, 1012),
(36, 4, 42, 50, 5, 750.00, 0, 143, 1012),
(37, 4, 43, 50, 5, 750.00, 0, 143, 1012),
(38, 4, 44, 50, 5, 750.00, 0, 143, 1012),
(39, 4, 45, 50, 5, 750.00, 0, 143, 1012),
(40, 4, 48, 50, 5, 750.00, 1, 143, 1012),
(41, 5, 0, 50, 5, 750.00, 0, 143, 1012),
(42, 5, 1, 50, 5, 750.00, 0, 143, 1012),
(43, 5, 4, 50, 5, 750.00, 0, 143, 1012),
(44, 5, 25, 50, 5, 750.00, 0, 143, 1012),
(45, 5, 26, 50, 5, 750.00, 0, 143, 1012),
(46, 5, 42, 50, 5, 750.00, 0, 143, 1012),
(47, 5, 43, 50, 5, 750.00, 0, 143, 1012),
(48, 5, 44, 50, 5, 750.00, 0, 143, 1012),
(49, 5, 45, 50, 5, 750.00, 0, 143, 1012),
(50, 5, 48, 50, 5, 750.00, 1, 143, 1012),
(51, 6, 1, 30, 3, 500.00, 0, 250, 250),
(52, 6, 4, 30, 3, 500.00, 0, 250, 250),
(53, 6, 25, 30, 3, 500.00, 0, 250, 250),
(54, 6, 26, 30, 3, 500.00, 0, 250, 250),
(55, 6, 42, 30, 3, 500.00, 0, 250, 250),
(56, 6, 43, 30, 3, 500.00, 0, 250, 250),
(57, 6, 44, 30, 3, 500.00, 0, 250, 250),
(58, 6, 45, 30, 3, 500.00, 0, 250, 250),
(59, 6, 48, 30, 3, 500.00, 1, 250, 250);

-- --------------------------------------------------------

--
-- Table structure for table `ad_payment`
--

CREATE TABLE IF NOT EXISTS `ad_payment` (
`payment_id` int(11) NOT NULL,
  `advetisement_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `price` double(12,2) NOT NULL,
  `discount_percentage` double(12,2) NOT NULL,
  `discounted_price` double(12,2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `ad_payment`
--

INSERT INTO `ad_payment` (`payment_id`, `advetisement_id`, `start_date`, `end_date`, `price`, `discount_percentage`, `discounted_price`) VALUES
(30, 30, '2015-04-16', '2015-07-14', 1000.00, 0.00, 1000.00),
(31, 31, '2015-04-16', '2015-07-14', 1000.00, 0.00, 1000.00),
(32, 32, '2015-04-16', '2015-07-14', 1000.00, 0.00, 1000.00),
(33, 33, '2015-04-16', '2015-06-05', 750.00, 0.00, 750.00),
(34, 34, '2015-04-16', '2015-06-05', 750.00, 0.00, 750.00),
(35, 35, '2015-04-16', '2015-06-05', 750.00, 5.00, 712.50),
(36, 36, '2015-04-16', '2015-06-05', 750.00, 10.00, 675.00),
(37, 37, '2015-04-16', '2015-06-05', 750.00, 0.00, 750.00),
(38, 38, '2015-04-16', '2015-06-05', 750.00, 10.00, 675.00),
(39, 39, '2015-04-17', '2015-07-15', 1000.00, 0.00, 1000.00),
(40, 40, '2015-04-17', '2015-06-06', 750.00, 10.00, 675.00),
(41, 41, '2015-04-17', '2015-06-06', 750.00, 0.00, 750.00),
(42, 42, '2015-04-17', '2015-06-06', 750.00, 0.00, 750.00),
(43, 43, '2015-04-17', '2015-06-06', 750.00, 12.00, 660.00),
(44, 44, '2015-04-17', '2015-05-16', 500.00, 30.00, 350.00),
(45, 45, '2015-04-17', '2015-05-16', 500.00, 0.00, 500.00),
(46, 46, '2015-04-17', '2015-05-16', 500.00, 25.00, 375.00),
(47, 47, '2015-04-17', '2015-05-16', 500.00, 0.00, 500.00),
(48, 48, '2015-04-17', '2015-05-16', 500.00, 0.00, 500.00),
(49, 49, '2015-04-18', '2015-07-16', 1000.00, 0.00, 1000.00),
(50, 50, '2015-04-19', '2015-07-17', 1000.00, 0.00, 1000.00),
(51, 51, '2015-04-19', '2015-07-17', 1000.00, 0.00, 1000.00),
(52, 52, '2015-04-19', '2015-07-17', 1000.00, 10.00, 900.00),
(53, 53, '2015-04-19', '2015-07-17', 1000.00, 0.00, 1000.00),
(54, 54, '2015-04-19', '2015-07-17', 1000.00, 10.00, 900.00);

-- --------------------------------------------------------

--
-- Table structure for table `ad_recommendations`
--

CREATE TABLE IF NOT EXISTS `ad_recommendations` (
`recommendation_id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT '0',
  `location_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` smallint(1) NOT NULL DEFAULT '1' COMMENT '1->Active,0->Inactive'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `ad_recommendations`
--

INSERT INTO `ad_recommendations` (`recommendation_id`, `property_id`, `location_id`, `admin_id`, `image_file`, `description`, `status`) VALUES
(1, 30, 0, 1, '1429018052.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio. Duis est nisl, finibus consequat cursus.', 1),
(2, 29, 0, 1, '1429018103.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(3, 24, 0, 1, '1429018150.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(4, 23, 0, 1, '1429018176.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(5, 18, 0, 1, '1429018211.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(6, 17, 1, 1, '1429018515.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(7, 16, 1, 1, '1429018573.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(8, 15, 1, 1, '1429018611.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(9, 14, 1, 1, '1429018673.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(10, 13, 1, 1, '1429187623.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio', 1),
(11, 31, 48, 1, '1429265952.png', 'Description for this 1st recommendation ad.', 1),
(12, 18, 48, 1, '1429266089.png', 'Description for this 2nd recommendation advertisement.', 1),
(13, 31, 48, 1, '1429266154.png', 'Description for this 3rd ad.', 1),
(14, 18, 48, 1, '1429266238.png', 'Description for this 4th recommendation advertisement', 1),
(15, 30, 48, 1, '1429266272.png', 'Description for this 5th recommendation advertisement', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ll_documents`
--

CREATE TABLE IF NOT EXISTS `ll_documents` (
`document_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_head_id` int(11) NOT NULL,
  `document_file` varchar(100) NOT NULL,
  `documentation_date` date NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `ll_documents`
--

INSERT INTO `ll_documents` (`document_id`, `user_id`, `document_head_id`, `document_file`, `documentation_date`, `expiry_date`) VALUES
(1, 1, 1, '1424677732116166.pdf', '2015-02-10', '2015-02-25'),
(2, 21, 1, '1428714759793294.jpg', '2015-04-11', '2015-06-26'),
(3, 21, 2, '1428714793496342.jpg', '2015-04-11', '0000-00-00'),
(4, 21, 2, '1428714966309524.jpg', '0000-00-00', '0000-00-00'),
(5, 21, 1, '1429260021526356.jpg', '2015-04-23', '2015-04-30'),
(6, 21, 1, '1429260055683054.jpg', '2015-04-21', '2015-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `ll_document_heads`
--

CREATE TABLE IF NOT EXISTS `ll_document_heads` (
`document_head_id` int(11) NOT NULL,
  `document_type` varchar(50) NOT NULL,
  `document_title` varchar(100) NOT NULL,
  `alert_before` int(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ll_document_heads`
--

INSERT INTO `ll_document_heads` (`document_head_id`, `document_type`, `document_title`, `alert_before`) VALUES
(1, '', 'Income Tax', 0),
(2, '', 'Fire Certificate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ll_document_tenancy`
--

CREATE TABLE IF NOT EXISTS `ll_document_tenancy` (
  `document_tenancy_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tenancy_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ll_document_tenancy`
--

INSERT INTO `ll_document_tenancy` (`document_tenancy_id`, `user_id`, `tenancy_id`, `document_id`) VALUES
(0, 1, 1, 1),
(0, 1, 3, 1),
(0, 21, 9, 2),
(0, 21, 9, 3),
(0, 21, 9, 4),
(0, 21, 9, 5),
(0, 21, 9, 6);

-- --------------------------------------------------------

--
-- Table structure for table `ll_tenancy`
--

CREATE TABLE IF NOT EXISTS `ll_tenancy` (
`tenancy_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `agreement_file` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `basis_term` varchar(25) NOT NULL,
  `amount` float NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `ll_tenancy`
--

INSERT INTO `ll_tenancy` (`tenancy_id`, `property_id`, `tenant_id`, `agreement_file`, `start_date`, `end_date`, `basis_term`, `amount`, `created_at`, `updated_at`) VALUES
(1, 6, 1, '1264474811.pdf', '2015-02-01', '2015-04-30', 'M', 100, 0, 0),
(2, 12, 2, '', '2015-02-23', '2015-06-30', 'M', 100, 0, 0),
(3, 14, 3, '4945111059.pdf', '2015-02-23', '2016-07-14', 'M', 100, 0, 0),
(4, 15, 4, '', '2015-02-23', '2015-02-23', 'M', 100, 0, 0),
(5, 16, 5, '', '2015-02-24', '2015-06-04', 'M', 100, 0, 0),
(6, 17, 6, '', '2015-02-24', '2015-07-16', 'M', 100, 0, 0),
(7, 23, 7, '', '0000-00-00', '0000-00-00', 'M', 100, 0, 0),
(8, 16, 8, '', '2015-04-07', '2015-06-04', 'M', 100, 0, 0),
(9, 29, 9, '', '2015-04-13', '2016-04-12', 'M', 100, 0, 0);

--
-- Triggers `ll_tenancy`
--
DELIMITER //
CREATE TRIGGER `trg_ai_tenancy` AFTER INSERT ON `ll_tenancy`
 FOR EACH ROW BEGIN UPDATE `pr_properties` SET `is_tenancy` = 1 WHERE `property_id` = NEW.property_id; END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ll_tenants`
--

CREATE TABLE IF NOT EXISTS `ll_tenants` (
`tenant_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `ll_tenants`
--

INSERT INTO `ll_tenants` (`tenant_id`, `first_name`, `last_name`, `phone`, `email`, `address`) VALUES
(1, 'Santanu', 'Brahma', '9876543210', 'santanu.brahma@geotechinfo.net', 'Sector-V, Saltlake.'),
(2, 'Santanu', 'Brahma', '9876543210', 'santanu.brahma@geotechinfo.net', 'Sector-V, Salt lake'),
(3, 'Santanu', 'Brahma', '9876543210', 'santanu.brahma@geotechinfo.net', 'Sector-V, Salt Lake.'),
(4, 'Tanwita ', 'Roy', '90090900', 'tanwita@gmail.com', 'sds road\r\n121'),
(5, 'Ridin', 'Dinesh', '3434', 'rififf@gmail.com', 'Bangkok'),
(6, 'Sandip', 'Roy', '23323232', 'sandip01@gmail.com', 'sds road\r\n121'),
(7, 'Nithi', 'Chansrichawla', '858232323', 'nithizz@gmail.com', 'vvv'),
(8, 'Sam', 'R', '3434', 'as@dsds.com', 'Bangkok'),
(9, 'Santanu', 'Brahma', '9748562316', 'nbasu9903@gmail.com', '15/16Airport rd.');

-- --------------------------------------------------------

--
-- Table structure for table `ll_transactions`
--

CREATE TABLE IF NOT EXISTS `ll_transactions` (
`transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tenancy_id` int(11) NOT NULL,
  `transaction_head_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `ll_transactions`
--

INSERT INTO `ll_transactions` (`transaction_id`, `user_id`, `tenancy_id`, `transaction_head_id`, `vendor_id`, `transaction_date`, `amount`) VALUES
(1, 0, 1, 1, 0, '2015-02-11', 1000),
(2, 0, 1, 1, 1, '2015-02-22', 5000),
(3, 0, 0, 2, 0, '2015-02-03', 1000),
(4, 0, 3, 1, 0, '2015-02-24', 250),
(5, 0, 3, 3, 1, '2015-02-16', 100),
(6, 0, 4, 2, 0, '2015-02-23', 10000),
(7, 0, 5, 2, 0, '2015-02-24', 1000),
(8, 0, 5, 3, 3, '2015-02-24', 20000),
(9, 0, 6, 1, 0, '2015-02-24', 20000),
(10, 0, 6, 2, 0, '2015-02-25', 10000),
(11, 0, 6, 3, 3, '2015-02-24', 5000),
(12, 2, 5, 1, 0, '2015-04-07', 123),
(13, 2, 8, 1, 0, '2015-04-07', 2000),
(14, 2, 8, 2, 0, '2015-04-07', 1000),
(15, 2, 5, 2, 0, '2015-04-07', 500),
(16, 2, 5, 3, 2, '2015-04-07', 456),
(17, 2, 8, 4, 0, '2015-04-07', 300),
(18, 21, 0, 2, 0, '2015-04-16', 25000),
(19, 21, 0, 3, 4, '2015-05-13', 5000),
(20, 21, 0, 4, 5, '2015-04-16', 600),
(21, 21, 0, 1, 0, '2015-04-17', 50000),
(22, 21, 0, 4, 6, '2015-04-16', 45000),
(23, 21, 9, 1, 0, '2015-04-17', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `ll_transaction_heads`
--

CREATE TABLE IF NOT EXISTS `ll_transaction_heads` (
`transaction_head_id` int(11) NOT NULL,
  `transaction_type` varchar(50) NOT NULL,
  `transaction_title` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ll_transaction_heads`
--

INSERT INTO `ll_transaction_heads` (`transaction_head_id`, `transaction_type`, `transaction_title`) VALUES
(1, 'Cash In', 'Deposit'),
(2, 'Cash In', 'Rent'),
(3, 'Cash Out', 'Maintenance'),
(4, 'Cash Out', 'Tax');

-- --------------------------------------------------------

--
-- Table structure for table `ll_vendors`
--

CREATE TABLE IF NOT EXISTS `ll_vendors` (
`vendor_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `vendor_phone` varchar(100) NOT NULL,
  `vendor_email` varchar(100) NOT NULL,
  `vendor_address` varchar(250) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `ll_vendors`
--

INSERT INTO `ll_vendors` (`vendor_id`, `user_id`, `vendor_name`, `vendor_phone`, `vendor_email`, `vendor_address`) VALUES
(1, 1, 'Bangkok Plumbers', '1234567890', 'abcd@abcd.com', 'Sample Address.'),
(2, 2, 'Dingo', '09090909', 'vendor@gdsd.com', 'sds road\r\n121'),
(3, 2, 'Nithi', '34343', 'nith@gsgs.com', 'sds road\r\n121'),
(4, 21, 'GeoTech', '9830356453', 'sudip.mitra@geotechinfo.net', '14/16 Marlin Infinite 801A'),
(5, 21, 'Income Tax Dept.', '9830356455', 'amit.thakur@geotechinfo.net', '16/19 IC office, Thailand'),
(6, 21, 'Ayan Bhattacharyya', '9681202319', 'ayan.bhattacharyya@geotechinfo.net', 'Kolkata');

-- --------------------------------------------------------

--
-- Table structure for table `nw_newsletters`
--

CREATE TABLE IF NOT EXISTS `nw_newsletters` (
  `newsletter_id` int(11) NOT NULL,
  `newsletter_user` varchar(255) NOT NULL,
  `newsletter_email` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nw_newsletters`
--

INSERT INTO `nw_newsletters` (`newsletter_id`, `newsletter_user`, `newsletter_email`, `created`) VALUES
(0, 'Neelanjan Basu', 'nbasu9903@gmail.com', '2015-04-10 17:28:09'),
(0, 'Neelanjan Basu', 'nbbabibasu5@gmail.com', '2015-04-11 00:13:56'),
(0, 'Neelanjan Basu', 'neelanjan.basu@geotechinfo.net', '2015-04-13 12:01:29'),
(0, 'Neelanjan Basu', 'neelanjan.basu@geotechinfo.net', '2015-04-13 12:02:02'),
(0, 'Shantanu', 'shj@yopmail.com', '2015-04-14 13:49:30'),
(0, 'Neelanjan Basu', 'nbasu85@gmail.com', '2015-04-16 05:51:49'),
(0, 'Neelanjan Basu', 'nbasuneelb@gmail.com', '2015-04-16 06:01:00'),
(0, 'Neelanjan Basu', 'neelbnbasu@gmail.com', '2015-04-16 08:13:58'),
(0, 'Tanwita  Roy', 'sanjibtefl@gmail.com', '2015-04-20 06:14:38');

-- --------------------------------------------------------

--
-- Table structure for table `pr_amenities`
--

CREATE TABLE IF NOT EXISTS `pr_amenities` (
`amenity_id` int(11) NOT NULL,
  `amenity_title` varchar(255) NOT NULL,
  `amenity_icon` varchar(255) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `pr_amenities`
--

INSERT INTO `pr_amenities` (`amenity_id`, `amenity_title`, `amenity_icon`) VALUES
(1, 'Swimming Pool', 'swimming.png'),
(2, 'Gymnasium', 'gym.png'),
(3, 'Library Pool', 'library.png'),
(4, 'Business Center with Discussion Rooms', 'discussion_rooms.png'),
(5, 'Cafe/Coffee Bar', 'coffee.png'),
(6, 'Multimedia Theater Room', 'theatre.png');

-- --------------------------------------------------------

--
-- Table structure for table `pr_attributes`
--

CREATE TABLE IF NOT EXISTS `pr_attributes` (
`attribute_id` int(11) NOT NULL,
  `attribute_name` varchar(50) NOT NULL,
  `attribute_type` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `pr_attributes`
--

INSERT INTO `pr_attributes` (`attribute_id`, `attribute_name`, `attribute_type`) VALUES
(1, 'Bedrooms', 'number'),
(2, 'Bathrooms', 'number'),
(3, 'Balcony', 'number'),
(4, 'Dinning / Drawing', 'number'),
(5, 'Kitchen', 'number'),
(6, 'Beds', 'number'),
(7, 'Furnishing', 'check'),
(8, 'Furnished', 'check'),
(9, 'ACs', 'number'),
(10, 'Modular Kitchen', 'check'),
(11, 'Water Heater', 'check'),
(12, 'Refrigerator', 'check'),
(13, 'Property on Floor', 'number'),
(14, 'Total Floors in Building', 'number'),
(15, 'Super built-up Area', 'text'),
(16, 'Built-up Area', 'text'),
(17, 'Carpet Area', 'text'),
(18, 'Rooms', 'number'),
(19, 'Washrooms', 'number'),
(20, 'Quality Rating', 'number'),
(21, 'Car parking slot', 'number'),
(22, '', 'text');

-- --------------------------------------------------------

--
-- Table structure for table `pr_deals`
--

CREATE TABLE IF NOT EXISTS `pr_deals` (
`deal_id` int(11) NOT NULL,
  `deal_name` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `pr_deals`
--

INSERT INTO `pr_deals` (`deal_id`, `deal_name`) VALUES
(1, 'Sell'),
(2, 'Rent'),
(3, 'Lease');

-- --------------------------------------------------------

--
-- Table structure for table `pr_groups`
--

CREATE TABLE IF NOT EXISTS `pr_groups` (
`group_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `group_name` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `pr_groups`
--

INSERT INTO `pr_groups` (`group_id`, `parent_id`, `group_name`) VALUES
(1, 0, 'Units'),
(2, 0, 'Furnishing'),
(3, 2, 'Furnished'),
(4, 2, 'Semi-furnished'),
(5, 2, 'Unfurnished'),
(6, 0, 'Floor Position'),
(7, 0, 'Area'),
(8, 0, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `pr_locations`
--

CREATE TABLE IF NOT EXISTS `pr_locations` (
`location_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `location_name` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `pr_locations`
--

INSERT INTO `pr_locations` (`location_id`, `parent_id`, `location_name`) VALUES
(1, 0, 'Bangkok'),
(2, 1, 'Asok'),
(3, 1, 'Nana'),
(4, 0, 'Phuket'),
(5, 4, 'Patong'),
(6, 4, 'Laguna'),
(7, 1, 'Aree'),
(8, 1, 'Banglampoo'),
(9, 1, 'Bang Na'),
(10, 1, 'Chatuchak'),
(11, 1, 'Chinatown'),
(12, 1, 'Din Daeng/Huai Khwang'),
(13, 1, 'Dusit'),
(14, 1, 'Klong Toey'),
(15, 1, 'Lower Sukhumvit'),
(16, 1, 'Pathum Wan'),
(17, 1, 'Phra Khanong'),
(18, 1, 'Sathorn'),
(19, 1, 'Siam'),
(20, 1, 'Silom'),
(21, 1, 'Thonburi'),
(22, 1, 'Thong Lo'),
(23, 1, 'Upper Sukhumvit'),
(24, 1, 'Victory Monument'),
(25, 0, 'Chiang Mai'),
(26, 0, 'Krabi'),
(27, 4, 'Ao Por'),
(28, 4, 'Bang Tao'),
(29, 4, 'Chalong'),
(30, 4, ' Kamala Beach'),
(31, 4, 'Karon Beach'),
(32, 4, 'Kata Beach'),
(33, 4, 'Koh Yao'),
(34, 4, 'Mai Khao'),
(35, 4, 'Nai Harn'),
(36, 4, 'Nai Thon'),
(37, 4, 'Nai Yang'),
(38, 4, 'Nearby Islands'),
(39, 4, 'Panwa'),
(40, 4, 'Patong Beach'),
(41, 4, 'Phuket Airport'),
(42, 0, 'Pattaya'),
(43, 0, 'Koh Samui'),
(44, 0, 'Chiang Rai'),
(45, 0, 'Surin'),
(46, 45, 'Chom Phra'),
(47, 25, 'Night Market'),
(48, 0, 'Chonburi'),
(49, 48, 'Laem Chabang');

-- --------------------------------------------------------

--
-- Table structure for table `pr_location_transports`
--

CREATE TABLE IF NOT EXISTS `pr_location_transports` (
`transport_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `transport_name` varchar(100) NOT NULL,
  `transport_icon` varchar(100) NOT NULL,
  `type` smallint(1) NOT NULL DEFAULT '1' COMMENT '1->Transport, 2->Near By'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `pr_location_transports`
--

INSERT INTO `pr_location_transports` (`transport_id`, `parent_id`, `location_id`, `transport_name`, `transport_icon`, `type`) VALUES
(1, 0, 1, 'BTS Stations (Silom Line)', 'bts.png', 1),
(2, 0, 1, 'MRT Stations', 'mrt.png', 1),
(3, 0, 1, 'Airport Rail Link', 'alink.png', 1),
(4, 1, 0, 'Mo Chit', '', 1),
(5, 1, 0, 'Nana', '', 1),
(6, 3, 0, 'Suvarnabhumi Airport', '', 1),
(7, 2, 0, 'Ari', '', 1),
(8, 2, 0, 'Sanam Pao', '', 1),
(9, 3, 0, 'Huamark', '', 1),
(10, 0, 1, 'Schools', 'school.png', 2),
(11, 10, 0, 'Suankularb Wittayalai School', '', 2),
(12, 10, 0, 'Saint Gabriel School', '', 2),
(13, 0, 1, 'Hospitals', 'hospital.png', 2),
(14, 13, 0, 'Thonglor Hospital', '', 2),
(15, 0, 1, 'University', 'university.png', 2),
(16, 1, 0, 'National Stadium', '', 1),
(17, 1, 0, 'Siam (BTS Intersection)', '', 1),
(18, 1, 0, 'Ratchadamri', '', 1),
(19, 1, 0, 'Sala Daeng', '', 1),
(20, 1, 0, 'Chong Nonsi', '', 1),
(21, 1, 0, 'Surasak', '', 1),
(22, 1, 0, 'Saphan Taksin', '', 1),
(23, 1, 0, 'Krung Thon Buri', '', 1),
(24, 1, 0, 'Wongwian Yai', '', 1),
(25, 1, 0, 'Pho Nimit', '', 1),
(26, 1, 0, 'Talat Phlu', '', 1),
(27, 1, 0, 'Wutthakat', '', 1),
(28, 1, 0, 'Bang Wa', '', 1),
(29, 1, 0, 'Mo Chit', '', 1),
(30, 0, 1, 'BTS Stations (Sukhumvit Line)', 'bts.png', 1),
(31, 30, 0, 'Mo chit', '', 1),
(32, 30, 0, 'Saphan Kwai', '', 1),
(33, 30, 0, 'Ari', '', 1),
(34, 30, 0, 'Sanam Pao', '', 1),
(35, 30, 0, 'Victory Monument', '', 1),
(36, 30, 0, 'Phaya Thai', '', 1),
(37, 30, 0, 'Ratchathewi', '', 1),
(38, 30, 0, 'Siam (BTS Intersection)', '', 1),
(39, 30, 0, 'Chit Lom', '', 1),
(40, 30, 0, 'Ploen Chit', '', 1),
(41, 30, 0, 'Nana', '', 1),
(42, 30, 0, 'Asok (MRT Intersection)', '', 1),
(43, 30, 0, 'Phrom Phong', '', 1),
(44, 30, 0, 'Thong Lo', '', 1),
(45, 30, 0, 'Ekkamai', '', 1),
(46, 30, 0, 'Phra Khanong', '', 1),
(47, 30, 0, 'On Nut', '', 1),
(48, 30, 0, 'Bang Chak', '', 1),
(49, 30, 0, 'Punnawithi', '', 1),
(50, 30, 0, 'Udom Suk', '', 1),
(51, 30, 0, 'Bang Na', '', 1),
(52, 30, 0, 'Bearing', '', 1),
(53, 2, 0, 'Hua Lamphong', '', 1),
(54, 2, 0, 'Sam Yan', '', 1),
(55, 2, 0, 'Si Lom', '', 1),
(56, 2, 0, 'Lumphini', '', 1),
(57, 2, 0, 'Khlong Toei', '', 1),
(58, 2, 0, 'Queen Sirikit National Convention Centre', '', 1),
(59, 2, 0, 'Sukhumvit', '', 1),
(60, 2, 0, 'Phetchaburi', '', 1),
(61, 2, 0, 'Phra Ram 9', '', 1),
(62, 2, 0, 'Thailand Cultural Centre', '', 1),
(63, 2, 0, 'Huai Khwang', '', 1),
(64, 2, 0, 'Sutthisan', '', 1),
(65, 2, 0, 'Ratchadaphisek', '', 1),
(66, 2, 0, 'Lat Phrao', '', 1),
(67, 2, 0, 'Phahon Yothin', '', 1),
(68, 2, 0, 'Chatuchak Park', '', 1),
(69, 2, 0, 'Kamphaeng Phet', '', 1),
(70, 2, 0, 'Bang Sue', '', 1),
(71, 0, 1, 'BRT Stations', 'bts.png', 1),
(72, 71, 0, 'Sathorn', '', 1),
(73, 71, 0, 'Arkhan Songkhro', '', 1),
(74, 71, 0, 'Yen Arkart', '', 1),
(75, 71, 0, 'Thanon Chan', '', 1),
(76, 71, 0, 'Nara-Rama III', '', 1),
(77, 71, 0, 'Wat Darn', '', 1),
(78, 71, 0, 'Wat Pariwas', '', 1),
(79, 71, 0, 'Wat Dorkmai', '', 1),
(80, 71, 0, 'Rama IX Bridge', '', 1),
(81, 71, 0, 'Charoen Rath', '', 1),
(82, 71, 0, 'Rama III Bridge', '', 1),
(83, 71, 0, 'Ratchpruek', '', 1),
(84, 3, 0, 'Suvarnabhumi Airport', '', 1),
(85, 3, 0, 'Lat Krabang', '', 1),
(86, 3, 0, 'Ban Thap Chang', '', 1),
(87, 3, 0, 'Hua Mark ', '', 1),
(88, 3, 0, 'Ramkhamhaeng', '', 1),
(89, 3, 0, 'Makkasan', '', 1),
(90, 3, 0, 'Rathchaprarop', '', 1),
(91, 3, 0, 'Phayathai', '', 1),
(92, 0, 45, 'Landmark', 'restaurant.png', 2),
(93, 92, 0, 'Dubai School of Science', '', 2),
(94, 92, 0, 'Dubai School of Commerce', '', 2),
(95, 0, 45, 'Ferry', 'swimming.png', 1),
(96, 95, 0, 'Loaded Truck', '', 1),
(97, 15, 0, 'Bangkok University', '', 2),
(98, 0, 48, 'BTS Stations (Via Chonburi)', 'bts.png', 1),
(99, 98, 0, 'Bang Wa', '', 1),
(100, 0, 48, 'Airport Link (via Chonburi)', 'alink.png', 1),
(101, 100, 0, 'Phayathai', '', 1),
(102, 0, 48, 'Railway station', 'railway.png', 2),
(103, 102, 0, 'Laem Chabang rail station', '', 2),
(104, 0, 1, 'Shopping Malls', 'theatre.png', 2),
(105, 104, 0, 'BigC', '', 2),
(106, 0, 1, 'Tourist Spots', 'park.png', 2),
(107, 106, 0, 'Wat Arun', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pr_media`
--

CREATE TABLE IF NOT EXISTS `pr_media` (
`media_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `media_type` varchar(50) NOT NULL,
  `media_title` varchar(100) NOT NULL,
  `media_data` varchar(250) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `pr_media`
--

INSERT INTO `pr_media` (`media_id`, `property_id`, `media_type`, `media_title`, `media_data`, `created_at`, `updated_at`) VALUES
(1, 1, 'PROPERTY-IMAGE', 'Description One', '1357377997.jpg', 0, 0),
(2, 1, 'PROPERTY-IMAGE', 'Description Two', '1118902461.jpg', 0, 0),
(3, 1, 'PROPERTY-IMAGE', 'Description Three', '1297583488.jpg', 0, 0),
(4, 1, 'PROPERTY-IMAGE', 'Description Four', '1225007151.jpg', 0, 0),
(5, 1, 'PROPERTY-IMAGE', 'Description Five', '1213119411.jpg', 0, 0),
(6, 4, 'PROPERTY-IMAGE', 'Description One', '1723062946.jpg', 0, 0),
(8, 4, 'PROPERTY-IMAGE', 'Description Three', '1815477087.jpg', 0, 0),
(9, 4, 'PROPERTY-IMAGE', 'Description Four', '1273610790.jpg', 0, 0),
(10, 4, 'PROPERTY-IMAGE', 'Description Five', '6855875050.jpg', 0, 0),
(11, 5, 'PROPERTY-IMAGE', 'Building View', '4165469345.jpg', 0, 0),
(15, 7, 'PROPERTY-IMAGE', 'Building View', '5267579816.jpg', 0, 0),
(16, 8, 'PROPERTY-IMAGE', 'Building View', '8768813150.jpg', 0, 0),
(18, 6, 'PROPERTY-IMAGE', 'Building', '1329049961.jpg', 0, 0),
(20, 6, 'PROPERTY-IMAGE', 'Bedroom 1', '1401434708.jpg', 0, 0),
(21, 6, 'PROPERTY-IMAGE', 'Bedroom 2', '1338675107.jpg', 0, 0),
(22, 11, 'PROPERTY-IMAGE', 'Locality', '3248196033.jpg', 0, 0),
(23, 11, 'PROPERTY-IMAGE', 'Building', '4805074863.jpg', 0, 0),
(24, 11, 'PROPERTY-IMAGE', 'Floor Plan', '3419688517.jpg', 0, 0),
(25, 11, 'PROPERTY-IMAGE', 'Bedroom 1', '4149498595.jpg', 0, 0),
(26, 11, 'PROPERTY-IMAGE', 'Bedroom 2', '5943002344.jpg', 0, 0),
(27, 12, 'PROPERTY-IMAGE', 'Locality', '8858662868.jpg', 0, 0),
(28, 12, 'PROPERTY-IMAGE', 'Building', '9353573682.jpg', 0, 0),
(29, 12, 'PROPERTY-IMAGE', 'Floor Plan', '6703071238.jpg', 0, 0),
(30, 13, 'PROPERTY-IMAGE', 'Locality', '1971746140.jpg', 0, 0),
(31, 14, 'PROPERTY-IMAGE', 'Locality', '2356853464.jpg', 0, 0),
(32, 15, 'PROPERTY-IMAGE', 'Locality', '1999475724.jpg', 0, 0),
(33, 15, 'PROPERTY-IMAGE', 'Building', '7059855684.jpg', 0, 0),
(34, 16, 'PROPERTY-IMAGE', 'Locality', '8362454254.jpg', 0, 0),
(35, 17, 'PROPERTY-IMAGE', 'Locality', '5853486508.jpg', 0, 0),
(36, 18, 'PROPERTY-IMAGE', 'Locality', '2237597451.jpg', 0, 0),
(37, 18, 'PROPERTY-IMAGE', 'Building', '4654857358.jpg', 0, 0),
(38, 18, 'PROPERTY-IMAGE', 'Floor Plan', '6391973702.jpg', 0, 0),
(39, 19, 'PROPERTY-IMAGE', 'Locality', '5654271932.jpg', 0, 0),
(40, 19, 'PROPERTY-IMAGE', 'Building', '5781574274.jpg', 0, 0),
(41, 19, 'PROPERTY-IMAGE', 'Floor Plan', '4248697927.jpg', 0, 0),
(42, 19, 'PROPERTY-IMAGE', 'Bedroom 1', '8784792870.jpg', 0, 0),
(43, 19, 'PROPERTY-IMAGE', 'Bedroom 2', '6956299381.jpg', 0, 0),
(44, 22, 'PROPERTY-IMAGE', 'Locality', '1701451258.jpg', 0, 0),
(45, 22, 'PROPERTY-IMAGE', 'Building', '4830286295.jpg', 0, 0),
(46, 22, 'PROPERTY-IMAGE', 'Floor Plan', '2236585372.jpg', 0, 0),
(47, 22, 'PROPERTY-IMAGE', 'Bedroom 1', '8108536468.jpg', 0, 0),
(48, 22, 'PROPERTY-IMAGE', 'Bedroom 2', '6167189685.jpg', 0, 0),
(49, 24, 'PROPERTY-IMAGE', 'Locality', '1649213623.jpg', 0, 0),
(50, 24, 'PROPERTY-IMAGE', 'Building', '7592840695.jpg', 0, 0),
(51, 24, 'PROPERTY-IMAGE', 'Floor Plan', '5008630922.jpg', 0, 0),
(52, 24, 'PROPERTY-IMAGE', 'Bedroom 1', '4857589109.jpg', 0, 0),
(53, 24, 'PROPERTY-IMAGE', 'Bedroom 2', '4782716325.jpg', 0, 0),
(54, 24, 'PROPERTY-IMAGE', 'Kitchen', '3444719902.jpg', 0, 0),
(55, 27, 'PROPERTY-IMAGE', 'Locality', '8118661120.jpg', 0, 0),
(56, 27, 'PROPERTY-IMAGE', 'Building', '2527179680.jpg', 0, 0),
(57, 27, 'PROPERTY-IMAGE', 'Floor Plan', '8220093349.jpg', 0, 0),
(58, 27, 'PROPERTY-IMAGE', 'Bedroom 1', '6629591964.jpg', 0, 0),
(59, 27, 'PROPERTY-IMAGE', 'Kitchen', '9868376639.jpg', 0, 0),
(60, 28, 'PROPERTY-IMAGE', 'Locality', '1958903993.jpg', 0, 0),
(61, 28, 'PROPERTY-IMAGE', 'Building', '3393446745.jpg', 0, 0),
(62, 28, 'PROPERTY-IMAGE', 'Floor Plan', '1749683548.jpg', 0, 0),
(63, 28, 'PROPERTY-IMAGE', 'Bedroom 1', '5087014242.jpg', 0, 0),
(64, 28, 'PROPERTY-IMAGE', 'Bedroom 2', '3308842339.jpg', 0, 0),
(65, 28, 'PROPERTY-IMAGE', 'Kitchen', '8546168679.jpg', 0, 0),
(66, 28, 'PROPERTY-IMAGE', 'Others', '1298589015.jpg', 0, 0),
(68, 22, 'PROPERTY-IMAGE', 'Locality', '1428672904_4_3.png', 0, 0),
(69, 29, 'PROPERTY-IMAGE', 'Locality', '1428712927_4_3.png', 0, 0),
(70, 30, 'PROPERTY-IMAGE', 'Locality', '1428713329_4_3.png', 0, 0),
(71, 30, 'PROPERTY-IMAGE', 'Building', '1428713329_4_3.png', 0, 0),
(73, 30, 'PROPERTY-IMAGE', 'Bedroom 1', '1428714421_4_3.png', 0, 0),
(74, 32, 'PROPERTY-IMAGE', 'Locality', '1429259259_4_3.png', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pr_properties`
--

CREATE TABLE IF NOT EXISTS `pr_properties` (
`property_id` int(11) NOT NULL,
  `property_code` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `location` int(11) NOT NULL,
  `location_sub` int(11) NOT NULL,
  `address` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `basis` varchar(25) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(150) NOT NULL,
  `last_active` bigint(20) NOT NULL,
  `is_tenancy` smallint(1) NOT NULL DEFAULT '0' COMMENT '0->No Tenancy,1->Tenancy',
  `is_featured` smallint(1) NOT NULL DEFAULT '0' COMMENT '1->Featured',
  `is_hot` smallint(1) NOT NULL DEFAULT '0' COMMENT '1->hot',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '0->Inactive,1->Active',
  `created_at` bigint(20) NOT NULL,
  `updated_at` bigint(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `pr_properties`
--

INSERT INTO `pr_properties` (`property_id`, `property_code`, `user_id`, `deal_id`, `type_id`, `title`, `description`, `location`, `location_sub`, `address`, `price`, `basis`, `phone`, `email`, `last_active`, `is_tenancy`, `is_featured`, `is_hot`, `status`, `created_at`, `updated_at`) VALUES
(1, 'PRO2485801', 1, 1, 4, 'House For Sale In Prachuap Khiri Khan', 'The villa is located 6 km west of Hua Hin city center in green lush surroundings. A new road has been build providing with good access roads and infrastructure to the area.\r\n\r\nThe estate has been completed 2 years ago and is today an effective estate consisting of 11 high class pool villas. The nearest surroundings to the estate are other villas providing a peaceful neighborhood\r\n\r\nThe villa has 3 bedrooms, 2 bathrooms and large kitchen- living room which opens up out onto a large covered terrac', 1, 3, 'Hua Hin, Asok. Bangkok. Thailand.', 6900000, 'O', '1234567890', 'pioneer.properties@gmail.com', 1424685494, 0, 0, 0, 1, 1, 0),
(2, 'PRO2460829', 0, 0, 0, 'House For Sale In Prachuap Khiri Khan1', 'The villa is located 6 km west of Hua Hin city center in green lush surroundings. A new road has been build providing with good access roads and infrastructure to the area.\r\n\r\nThe estate has been completed 2 years ago and is today an effective estate consisting of 11 high class pool villas. The nearest surroundings to the estate are other villas providing a peaceful neighborhood\r\n\r\nThe villa has 3 bedrooms, 2 bathrooms and large kitchen- living room which opens up out onto a large covered terrac', 0, 0, 'Hua Hin, Asok. Bangkok. Thailand.', 6900000, 'O', '1234567890', 'pioneer.properties@gmail.com', 0, 0, 0, 0, 1, 1, 0),
(3, 'PRO2446744', 0, 0, 0, 'House For Sale In Prachuap Khiri Khan1', 'The villa is located 6 km west of Hua Hin city center in green lush surroundings. A new road has been build providing with good access roads and infrastructure to the area.\r\n\r\nThe estate has been completed 2 years ago and is today an effective estate consisting of 11 high class pool villas. The nearest surroundings to the estate are other villas providing a peaceful neighborhood\r\n\r\nThe villa has 3 bedrooms, 2 bathrooms and large kitchen- living room which opens up out onto a large covered terrac', 0, 0, 'Hua Hin, Asok. Bangkok. Thailand.', 6900000, 'O', '1234567890', 'pioneer.properties@gmail.com', 0, 0, 0, 0, 1, 1, 0),
(4, 'PRO2451230', 1, 1, 4, 'Townhouse For Sale In Bangkok, Bangkok Central', 'Beautifully presented 4 storey Townhouse located on up-and-coming Sukhumvit 107.\r\n\r\nThe property offers a luxury and spacious living experience and it is fully equipped with all the modern living requirements such as double parking space, private pool and a roof terrace.\r\n\r\nThe townhouse will be kitted with the highest quality finish such as oak floors in the bedrooms and luxury fittings throughout the property. The developer can customize the layout, fixtures and furnishings of the Townhouse ac', 1, 2, 'Bangkok Central, Bearing', 20000, 'O', '55555555', 'pioneer.properties@gmail.com', 1424678914, 0, 0, 0, 1, 1, 0),
(5, 'PRO2415922', 2, 1, 4, 'Sunrise Properties', 'Sunrise Property test data', 1, 2, 'Soi 32, Asok \r\nBangkok', 100000, 'M', '8989898', 'sandip01@gmail.com', 1428750226, 0, 0, 0, 1, 1, 0),
(6, 'PRO2425918', 1, 1, 4, 'House For Sale In Phuket', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop p', 1, 2, 'efgbkaefejkfgjkgsek\r\nghsdghsklghl\r\n12333243454', 125455, 'O', '1234567890', 'pioneer.properties@gmail.com', 1424240832, 0, 0, 0, 1, 1, 0),
(7, 'PRO2481824', 2, 1, 4, 'Silver Spring', 'G-121 . Sukantanagar well communicated location .With basic amenities available at affordable range .Science city , Mani square , Nalban railway station all at 15 mins distance. Semi furnished .. Well decorated interiors', 0, 0, 'laguna soi 22', 5600000, 'O', '8989898', 'sandip01@gmail.com', 1424710286, 0, 0, 0, 1, 1, 0),
(8, 'PRO2431369', 3, 1, 4, 'Silver Valley', 'Silver Valley  Silver ValleyS ilver ValleySilver ValleySilver  ValleySilver ValleySilver ValleySilver ValleySilver  ValleySilver  ValleySilver Valley', 0, 0, 'Asok Soi 33', 6000000, 'O', '56456456', 'tanwita@gmail.com', 0, 0, 0, 0, 1, 1, 0),
(9, 'PRO2411372', 7, 2, 8, 'Cham Chand Court', '50 square meter apartment with 2 bedrooms and 10 toilet. Best for living and launching a mini rock concert.', 0, 0, 'Asoke, Red Light District, Soi 69.', 40000, 'M', '894503647', 'ridindinesh@gmail.com', 0, 0, 0, 0, 1, 1, 0),
(10, 'PRO2462755', 7, 2, 8, 'Cham Chand Court', '50 square meter apartment with 2 bedrooms and 10 toilet. Best for living and launching a mini rock concert.', 0, 0, 'Asoke, Red Light District, Soi 69.', 40000, 'M', '894503647', 'ridindinesh@gmail.com', 0, 0, 0, 0, 1, 1, 0),
(11, 'PRO2479660', 1, 2, 4, 'House For Sale In Prachuap Khiri Khan2', 'Nirmal Lifestyle is an imprint of the renowned Nirmal Group; an ISO 9001:2008 and ISO 14001:2004 certified company. The group is credited to have spearheaded the development of Mulund over the years. Nirmal Lifestyle Mulund is driven by knowledge and innovation in property development. The builders have been responsible for the development of over one crore square feet of residential and commercial spaces. The company is dedicated to customer satisfaction. It comprises of an efficient core group', 1, 2, 'Sample address, Asok.', 50000, 'M', '1234567890', 'pioneer.properties@gmail.com', 1424694420, 0, 0, 0, 1, 1, 0),
(12, 'PRO2410034', 1, 2, 4, 'Nirmal Lifestyle', 'Nirmal Lifestyle is an imprint of the renowned Nirmal Group; an ISO 9001:2008 and ISO 14001:2004 certified company. The group is credited to have spearheaded the development of Mulund over the years. Nirmal Lifestyle Mulund is driven by knowledge and innovation in property development. The builders have been responsible for the development of over one crore square feet of residential and commercial spaces. The company is dedicated to customer satisfaction. It comprises of an efficient core group', 1, 2, 'Sample Address, Asok,  Bangkok.', 2500, 'M', '1234567890', 'pioneer.properties@gmail.com', 1424696123, 1, 0, 0, 1, 1, 0),
(13, 'PRO2411192', 1, 2, 4, 'Onyx Residences / Marriott Executive Apartments - Pattaya', 'The building is located on Pratumnak Soi 5, Pratumnak Hill is Pattaya’s most prestigious neighbourhood where hip restaurants mix with charming beach cafés, bars and bistros. Yet it’s also rich in culture sitting under the gaze of the Giant Buddha and the Temple at the top of Pratumnak Hill. Onyx Residence floats high above the glittering beach resort, making it the perfect vantage point from which to see the lights of the city. Just 700 meters from a beautiful sandy beach where you can relax and', 1, 2, 'Sample Address, Pataya.', 480, 'M', '1234567890', 'pioneer.properties@gmail.com', 1425477268, 0, 1, 1, 1, 1, 0),
(14, 'PRO2425860', 1, 2, 4, 'Condo For Sale In Chonburi, Pattaya, Jomtien', 'The one bedroom modern condo. Each of the rooms are fully furnished to a high standard with strong use of neutral colours and high quality materials, including fully fitted western style kitchens and bathrooms, as well as air conditioning throughout. ', 1, 2, 'Sector-V, Salt Lake.', 1850, 'M', '1234567890', 'pioneer.properties@gmail.com', 1425477262, 1, 0, 0, 1, 1, 0),
(15, 'PRO2495721', 2, 2, 4, 'ISIS Properties', '2 BHK multistorey apartment with attached bathroom is available for sale. Dream of a home where you can perceive and cherish every discreet event sewed up with nature all day. Where the sound of falling leaves would greet you good morning, the soft breeze will teach music to the little ones and chirping birds will make each sip of your tea heavenly. The property is well-connected to Schools, Hospitals, Markets and Railway Station. Please call for more details.', 4, 5, 'Patong Beach, Phuket', 100000, 'M', '8989898', 'sandip01@gmail.com', 1424711034, 1, 0, 0, 1, 1, 0),
(16, 'PRO2410280', 2, 2, 4, 'BKK Properties', 'fsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdffsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdf fsdfsdfs sd fsd f sd fsd f sdf sd f dfsd  fsdf', 1, 9, 'Laguna Phuket', 10000, 'M', '8989898', 'sandip01@gmail.com', 1427896960, 1, 0, 0, 1, 1, 0),
(17, 'PRO2417975', 2, 2, 4, 'Pratheep Properties', 'asdsdas asd sad as das d asd as asdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd asasdsdas asd sad as das d asd as', 1, 2, 'Asok, ', 10000, 'M', '8989898', 'sandip01@gmail.com', 1424754916, 1, 0, 0, 1, 1, 0),
(18, 'PRO2486791', 1, 2, 4, 'Rent Property 1', 'Description for Rent property 1', 1, 2, 'Asok, Thailand', 1320000, 'Q', '1234567890', 'pioneer.properties@gmail.com', 1425478258, 0, 0, 0, 1, 1, 0),
(19, 'PRO2480030', 1, 2, 4, 'House For Sale In Surat Thani, Koh Pha-ngan', 'The Modern Tropical Designs are open and bright with high ceilings and doors that open fully onto deep covered terraces with infinity swimming pools, outdoor living and dining areas, offering either 200 or 300 SQM of an indoor/outdoor lifestyle space. Daylight streams in through the full height windows and reflects off the high ceilings to give a senses of open flowing space throughout. The heart of each villa is the spacious open plan living area where the kitchen, dining room and lounge form o', 1, 2, 'Sample Address!', 1500, 'M', '1234567890', 'pioneer.properties@gmail.com', 1425479583, 0, 0, 0, 0, 1, 0),
(20, 'PRO2439779', 1, 2, 4, 'House For Sale In Surat Thani, Koh Pha-ngan', 'The Modern Tropical Designs are open and bright with high ceilings and doors that open fully onto deep covered terraces with infinity swimming pools, outdoor living and dining areas, offering either 200 or 300 SQM of an indoor/outdoor lifestyle space. Daylight streams in through the full height windows and reflects off the high ceilings to give a senses of open flowing space throughout. The heart of each villa is the spacious open plan living area where the kitchen, dining room and lounge form o', 1, 2, 'Sample Address!', 1500, 'M', '1234567890', 'pioneer.properties@gmail.com', 1425479611, 0, 0, 0, 0, 1, 0),
(21, 'PRO2458807', 1, 2, 4, 'House For Sale In Surat Thani, Koh Pha-ngan', 'The Modern Tropical Designs are open and bright with high ceilings and doors that open fully onto deep covered terraces with infinity swimming pools, outdoor living and dining areas, offering either 200 or 300 SQM of an indoor/outdoor lifestyle space. Daylight streams in through the full height windows and reflects off the high ceilings to give a senses of open flowing space throughout. The heart of each villa is the spacious open plan living area where the kitchen, dining room and lounge form o', 1, 2, 'Sample Address!', 1500, 'M', '1234567890', 'pioneer.properties@gmail.com', 1425479714, 0, 0, 0, 0, 1, 0),
(22, 'PRO2474697', 1, 1, 4, 'House For Sale In Surat Thani, Koh Pha-ngan', 'The Modern Tropical Designs are open and bright with high ceilings and doors that open fully onto deep covered terraces with infinity swimming pools, outdoor living and dining areas, offering either 200 or 300 SQM of an indoor/outdoor lifestyle space. Daylight streams in through the full height windows and reflects off the high ceilings to give a senses of open flowing space throughout. The heart of each villa is the spacious open plan living area where the kitchen, dining room and lounge form o', 1, 2, 'test address', 1200, 'M', '1234567890', 'pioneer.properties@gmail.com', 1428672931, 0, 0, 0, 0, 1, 0),
(23, 'PRO2497064', 14, 2, 4, 'BK PLACE SUKHUMVIT 71', 'SOME HOME AT SUKHUMVIT 71', 1, 2, 'sUKHUMVIT 71 pRIDI 21\r\n', 100, 'W', '850675114', 'pratheeps.sethi@gmail.com', 1425632154, 1, 1, 0, 1, 1, 0),
(24, 'PRO2426492', 15, 1, 4, 'Pidi Residents', '3 Bedroom apartment, pet friendly, 2 km from BTS phrakhong', 1, 2, '265/5 Phrakhanong Soi 14, Yeak 3, Sukhumvi Road, Bangkok, 10110\r\n', 27000, 'M', '894503646', 'ridindinesh@yahoo.com', 1425908374, 0, 0, 0, 1, 0, 0),
(25, 'PRO2569098', 18, 1, 4, 'ABCDEaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 1, 8, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 1, 'M', '812862323', 'nchansrichawla@gmail.com', 1426208563, 0, 0, 0, 0, 0, 0),
(26, 'PRO2664829', 19, 2, 4, 'K.K Residence', 'Apartment for rent.', 1, 17, '391 Soi Pridi Banomyong 19 K.K Residence Sukhumvit 71 Bangkok 10110 Thailand', 30000, 'M', '811161100', 'schansrichavala@gmail.com', 1426214632, 0, 0, 0, 0, 0, 0),
(27, 'PRO2759578', 20, 2, 4, 'NBasu Property 1', 'Description for the property NBasu Property 1.', 4, 6, 'Laguna, Phuket', 10000, 'M', '9903717914', 'neelanjan.basu@geotechinfo.net', 1426752249, 0, 0, 0, 0, 0, 0),
(28, 'PRO2893858', 20, 3, 21, 'NBasu Industrial Land Property', 'Description of the property NBasu Industrial Land Property.', 45, 46, '12/13 Omat, Dubai', 2500000, 'M', '9903717914', 'neelanjan.basu@geotechinfo.net', 1429173774, 0, 0, 1, 1, 0, 0),
(29, 'PRO2926623', 21, 2, 10, 'NBasu property 1 for rent', ' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio. Duis est nisl, finibus consequat cursus in, hendrerit in leo. Praesent sed ullamcorper justo. Morbi sagittis vehicula eros, ut fermentum risus varius sit amet. Integer purus ligula, egestas in sagittis quis, vehicula at tellus. Pellentesque mattis consequat ex, nec bibendum tellus varius eu. Vivamus ac ex orci.\r\n\r\nCurabitur aliquet leo quis sodales dapibus. Fusce neque lacus, condimentum sit amet porta vel, euismod id eros. Fusce nec volutpat dui, non dapibus ipsum. Curabitur venenatis tincidunt diam, ac blandit lectus vehicula ut. Fusce commodo suscipit laoreet. Nam gravida justo lorem, eget rutrum nibh pulvinar ut. Pellentesque commodo condimentum nisl, vitae vestibulum mauris egestas in. Pellentesque elementum eu elit vitae pretium. Donec a vehicula lorem, et sodales libero. Proin id tincidunt sapien, ac finibus eros. Etiam quis sapien eu nisl tristique lacinia. Nulla aliquet interdum purus sed accumsan. Pellentesque faucibus ante condimentum lorem ornare, ac eleifend arcu lobortis. Maecenas vehicula varius metus, a gravida libero congue ac. Suspendisse potenti. Ut non congue lectus.\r\n\r\nPhasellus mattis vehicula ex, et cursus nibh feugiat sed. Duis id enim est. Nam venenatis cursus metus, ut vulputate nunc vestibulum sit amet. Vivamus vel lacinia dui. Donec eleifend eleifend est in auctor. Suspendisse vel magna massa. Duis malesuada sit amet dolor sit amet sodales.\r\n\r\nVestibulum varius consectetur erat, in volutpat metus laoreet sit amet. Quisque mauris sem, faucibus molestie blandit sit amet, facilisis pulvinar diam. Suspendisse fringilla leo ac blandit dictum. Duis vitae lorem aliquet, lacinia ligula vitae, consectetur dui. Morbi posuere massa cursus cursus vehicula. Sed ornare ligula ut velit imperdiet, sit amet vestibulum purus pulvinar. Praesent sodales eros et felis tempus volutpat. Pellentesque condimentum sem', 48, 49, 'Address goes here later.', 25000, 'M', '9903717917', 'nbbabibasu5@gmail.com', 1428712927, 1, 1, 0, 1, 0, 0),
(30, 'PRO3036528', 21, 2, 4, 'NBasu property 2 for rent', ' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum pharetra leo ut auctor. Vivamus nec mattis velit, in tincidunt odio. Duis est nisl, finibus consequat cursus in, hendrerit in leo. Praesent sed ullamcorper justo. Morbi sagittis vehicula eros, ut fermentum risus varius sit amet. Integer purus ligula, egestas in sagittis quis, vehicula at tellus. Pellentesque mattis consequat ex, nec bibendum tellus varius eu. Vivamus ac ex orci.\r\n\r\nCurabitur aliquet leo quis sodales dapibus. Fusce neque lacus, condimentum sit amet porta vel, euismod id eros. Fusce nec volutpat dui, non dapibus ipsum. Curabitur venenatis tincidunt diam, ac blandit lectus vehicula ut. Fusce commodo suscipit laoreet. Nam gravida justo lorem, eget rutrum nibh pulvinar ut. Pellentesque commodo condimentum nisl, vitae vestibulum mauris egestas in. Pellentesque elementum eu elit vitae pretium. Donec a vehicula lorem, et sodales libero. Proin id tincidunt sapien, ac finibus eros. Etiam quis sapien eu nisl tristique lacinia. Nulla aliquet interdum purus sed accumsan. Pellentesque faucibus ante condimentum lorem ornare, ac eleifend arcu lobortis. Maecenas vehicula varius metus, a gravida libero congue ac. Suspendisse potenti. Ut non congue lectus.\r\n\r\nPhasellus mattis vehicula ex, et cursus nibh feugiat sed. Duis id enim est. Nam venenatis cursus metus, ut vulputate nunc vestibulum sit amet. Vivamus vel lacinia dui. Donec eleifend eleifend est in auctor. Suspendisse vel magna massa. Duis malesuada sit amet dolor sit amet sodales.\r\n\r\nVestibulum varius consectetur erat, in volutpat metus laoreet sit amet. Quisque mauris sem, faucibus molestie blandit sit amet, facilisis pulvinar diam. Suspendisse fringilla leo ac blandit dictum. Duis vitae lorem aliquet, lacinia ligula vitae, consectetur dui. Morbi posuere massa cursus cursus vehicula. Sed ornare ligula ut velit imperdiet, sit amet vestibulum purus pulvinar. Praesent sodales eros et felis tempus volutpat. Pellentesque condimentum sem', 48, 49, '12/16Thailand rd.', 33000, 'M', '9903717919', 'nbbabibasu5@gmail.com', 1429173265, 0, 1, 1, 1, 0, 0),
(31, 'PRO3166565', 21, 1, 4, 'NBasu Sell Property 3', 'Description for this property.', 48, 49, '10/11 Chonburi, Thailand', 30000, 'M', '9903717917', 'neelanjan.basu@geotechinfo.net', 1429174170, 0, 1, 1, 1, 0, 0),
(32, 'PRO3262266', 21, 1, 23, 'Nbasu Condo Property 1', 'Description for this property.', 48, 49, '16/17 Chonburi, Thailand', 50000, 'M', '9903717917', 'nbbabibasu5@gmail.com', 1429259259, 0, 1, 1, 1, 0, 0);

--
-- Triggers `pr_properties`
--
DELIMITER //
CREATE TRIGGER `trg_bi_properties` BEFORE INSERT ON `pr_properties`
 FOR EACH ROW BEGIN
	DECLARE SPV_R INT(5);
    DECLARE SPV_MAX_ID INT(11);
    SET SPV_MAX_ID = (SELECT MAX(property_id) FROM pr_properties)+1;
    SET SPV_R = RAND()*1000000;
	SET NEW.property_code = CONCAT('PRO',SPV_MAX_ID,SPV_R);
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `pr_property_amenities`
--

CREATE TABLE IF NOT EXISTS `pr_property_amenities` (
`property_amenity_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `amenity_id` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `pr_property_amenities`
--

INSERT INTO `pr_property_amenities` (`property_amenity_id`, `property_id`, `amenity_id`) VALUES
(4, 18, 5),
(3, 18, 1),
(5, 19, 1),
(6, 19, 2),
(7, 19, 4),
(8, 19, 6),
(9, 20, 1),
(10, 20, 2),
(11, 20, 4),
(12, 20, 6),
(13, 21, 1),
(14, 21, 2),
(15, 21, 4),
(16, 21, 6),
(65, 22, 3),
(64, 22, 2),
(63, 22, 1),
(23, 23, 1),
(24, 23, 2),
(25, 24, 1),
(26, 24, 2),
(27, 24, 3),
(28, 24, 4),
(29, 24, 5),
(30, 24, 6),
(31, 25, 1),
(32, 25, 5),
(33, 26, 2),
(34, 27, 1),
(35, 27, 2),
(36, 27, 3),
(95, 28, 6),
(94, 28, 3),
(93, 28, 2),
(52, 16, 5),
(51, 16, 4),
(50, 16, 3),
(49, 16, 2),
(48, 16, 1),
(53, 16, 6),
(71, 29, 4),
(70, 29, 3),
(69, 29, 2),
(92, 30, 3),
(91, 30, 2),
(90, 30, 1),
(105, 31, 6),
(104, 31, 5),
(103, 31, 3),
(102, 31, 2),
(101, 31, 1),
(106, 32, 3),
(107, 32, 5),
(108, 32, 6);

-- --------------------------------------------------------

--
-- Table structure for table `pr_property_transport`
--

CREATE TABLE IF NOT EXISTS `pr_property_transport` (
`id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `transport_id` int(11) NOT NULL,
  `distance` double(10,3) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=218 ;

--
-- Dumping data for table `pr_property_transport`
--

INSERT INTO `pr_property_transport` (`id`, `property_id`, `transport_id`, `distance`) VALUES
(53, 4, 4, 0.000),
(54, 4, 9, 0.000),
(55, 1, 4, 10.000),
(56, 1, 7, 20.000),
(57, 1, 9, 30.000),
(58, 6, 4, 10.000),
(59, 6, 7, 20.000),
(60, 6, 6, 30.000),
(61, 0, 4, 2.000),
(62, 0, 7, 5.000),
(63, 0, 6, 4.000),
(64, 0, 11, 2.000),
(65, 0, 12, 1.000),
(66, 11, 4, 10.000),
(67, 11, 7, 2.000),
(68, 11, 6, 2.000),
(69, 11, 11, 0.000),
(70, 11, 12, 0.000),
(71, 0, 5, 0.000),
(72, 0, 11, 0.000),
(73, 0, 12, 0.000),
(74, 12, 5, 0.000),
(75, 12, 0, 0.000),
(76, 12, 0, 0.000),
(77, 0, 4, 2.000),
(78, 0, 8, 1.000),
(79, 0, 6, 0.000),
(80, 0, 11, 1.000),
(81, 0, 14, 0.000),
(82, 14, 4, 1.000),
(83, 14, 8, 2.000),
(84, 14, 6, 3.000),
(85, 14, 12, 1.000),
(86, 14, 14, 3.000),
(88, 17, 5, 0.000),
(89, 17, 11, 1.000),
(96, 18, 4, 0.000),
(97, 18, 7, 0.000),
(98, 18, 9, 0.000),
(99, 18, 11, 0.000),
(100, 18, 12, 0.000),
(101, 18, 14, 0.000),
(102, 19, 4, 0.000),
(103, 19, 7, 0.000),
(104, 19, 9, 0.000),
(105, 19, 11, 2.000),
(106, 19, 12, 3.000),
(107, 19, 14, 5.000),
(108, 20, 4, 0.000),
(109, 20, 7, 0.000),
(110, 20, 9, 0.000),
(111, 20, 11, 2.000),
(112, 20, 12, 3.000),
(113, 20, 14, 5.000),
(114, 21, 4, 0.000),
(115, 21, 7, 0.000),
(116, 21, 9, 0.000),
(117, 21, 11, 2.000),
(118, 21, 12, 3.000),
(119, 21, 14, 5.000),
(123, 23, 5, 3.000),
(124, 23, 6, 3.000),
(125, 23, 12, 0.000),
(126, 23, 14, 0.000),
(127, 24, 4, 10.000),
(128, 24, 8, 20.000),
(129, 24, 6, 15.000),
(130, 24, 11, 20.000),
(131, 24, 12, 20.000),
(132, 24, 14, 15.000),
(133, 25, 4, 0.000),
(134, 25, 7, 0.000),
(135, 25, 9, 0.000),
(136, 25, 11, 0.000),
(137, 26, 4, 0.000),
(138, 26, 7, 0.000),
(139, 26, 6, 0.000),
(140, 26, 14, 0.000),
(141, 27, 11, 21.000),
(142, 27, 14, 0.000),
(147, 16, 0, 0.000),
(148, 16, 0, 0.000),
(149, 16, 0, 0.000),
(150, 16, 0, 0.000),
(151, 16, 0, 0.000),
(169, 22, 0, 0.000),
(170, 22, 0, 0.000),
(171, 22, 0, 0.000),
(172, 22, 0, 0.000),
(173, 22, 0, 0.000),
(174, 22, 14, 23.000),
(178, 29, 99, 5.000),
(179, 29, 101, 6.000),
(180, 29, 103, 6.000),
(199, 5, 23, 0.000),
(200, 5, 0, 0.000),
(201, 5, 0, 0.000),
(202, 5, 0, 0.000),
(203, 5, 0, 0.000),
(204, 30, 99, 5.000),
(205, 30, 101, 6.000),
(206, 30, 103, 19.000),
(207, 28, 96, 36.000),
(208, 28, 93, 6.000),
(212, 31, 99, 5.000),
(213, 31, 101, 5.000),
(214, 31, 103, 14.000),
(215, 32, 99, 6.000),
(216, 32, 0, 0.000),
(217, 32, 103, 7.000);

-- --------------------------------------------------------

--
-- Table structure for table `pr_relations`
--

CREATE TABLE IF NOT EXISTS `pr_relations` (
`relation_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `pr_relations`
--

INSERT INTO `pr_relations` (`relation_id`, `deal_id`, `type_id`, `group_id`, `attribute_id`) VALUES
(1, 1, 4, 1, 1),
(2, 1, 4, 1, 2),
(3, 1, 4, 1, 3),
(4, 1, 4, 1, 4),
(5, 1, 4, 1, 5),
(6, 1, 4, 8, 8),
(7, 1, 4, 6, 13),
(8, 1, 4, 6, 14),
(9, 1, 4, 7, 15),
(10, 1, 4, 7, 16),
(11, 1, 4, 7, 17),
(12, 2, 4, 1, 1),
(13, 2, 4, 1, 2),
(14, 2, 4, 1, 3),
(15, 2, 4, 1, 4),
(16, 2, 4, 1, 5),
(17, 2, 4, 3, 6),
(18, 2, 4, 3, 9),
(19, 2, 4, 3, 10),
(20, 2, 4, 3, 11),
(21, 2, 4, 3, 12),
(22, 3, 21, 6, 6),
(23, 3, 19, 7, 1),
(24, 0, 0, 1, 1),
(25, 0, 5, 1, 1),
(26, 1, 7, 3, 20),
(27, 1, 23, 1, 1),
(28, 2, 10, 3, 21),
(29, 1, 10, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pr_types`
--

CREATE TABLE IF NOT EXISTS `pr_types` (
`type_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `pr_types`
--

INSERT INTO `pr_types` (`type_id`, `parent_id`, `type_name`) VALUES
(1, 0, 'Residential'),
(2, 0, 'Commercial'),
(3, 0, 'Land'),
(4, 1, 'Residential Apartment '),
(5, 1, 'Independent House / Villa'),
(6, 1, 'Independent / Builder Floor'),
(7, 1, 'Farm House'),
(8, 1, 'Studio Apartments'),
(9, 1, 'Serviced Apartment'),
(10, 2, 'Office Space'),
(11, 2, 'Shop'),
(12, 2, 'Showroom'),
(13, 2, 'Factory'),
(14, 2, 'Warehouse'),
(15, 2, 'Hotel / Resort'),
(16, 2, 'Guest House'),
(17, 2, 'Banquet Hall'),
(18, 2, 'Space in Retail Mall'),
(19, 3, 'Residential Land'),
(20, 3, 'Commercial Land'),
(21, 3, 'Industrial Land'),
(22, 3, 'Agricultural / Farm Land'),
(23, 1, 'Condos');

-- --------------------------------------------------------

--
-- Table structure for table `pr_values`
--

CREATE TABLE IF NOT EXISTS `pr_values` (
`value_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `attribute_value` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=844 ;

--
-- Dumping data for table `pr_values`
--

INSERT INTO `pr_values` (`value_id`, `property_id`, `attribute_id`, `attribute_value`) VALUES
(143, 7, 1, '2'),
(144, 7, 2, '1'),
(145, 7, 3, '1'),
(146, 7, 4, '1'),
(147, 7, 5, '1'),
(148, 7, 13, '1'),
(149, 7, 14, '2'),
(150, 7, 15, '500'),
(151, 7, 16, '450'),
(152, 7, 17, '400'),
(153, 8, 1, '2'),
(154, 8, 2, '1'),
(155, 8, 3, '1'),
(156, 8, 4, '1'),
(157, 8, 5, '1'),
(158, 8, 8, 'Yes'),
(159, 8, 13, '1'),
(160, 8, 14, '1'),
(161, 8, 15, '244'),
(162, 8, 16, '233'),
(163, 8, 17, '222'),
(454, 4, 1, '2'),
(455, 4, 2, '2'),
(456, 4, 3, '2'),
(457, 4, 4, '2'),
(458, 4, 5, '2'),
(459, 4, 13, '3'),
(460, 4, 14, '3'),
(461, 4, 15, '200'),
(462, 4, 16, '700'),
(463, 4, 17, '600'),
(464, 1, 1, '3'),
(465, 1, 2, '2'),
(466, 1, 3, '1'),
(467, 1, 4, '1'),
(468, 1, 5, '1'),
(469, 1, 13, '4'),
(470, 1, 14, '6'),
(471, 1, 15, '800'),
(472, 1, 16, '700'),
(473, 1, 17, '600'),
(474, 6, 1, '1'),
(475, 6, 2, '2'),
(476, 6, 3, '1'),
(477, 6, 4, '1'),
(478, 6, 5, '4'),
(479, 6, 13, '2'),
(480, 6, 14, '2'),
(481, 6, 15, '1434'),
(482, 6, 16, '3434'),
(483, 6, 17, '3543'),
(494, 11, 1, '2'),
(495, 11, 2, '2'),
(496, 11, 3, '2'),
(497, 11, 4, '2'),
(498, 11, 5, '2'),
(499, 11, 6, '2'),
(500, 11, 9, '2'),
(509, 12, 1, '3'),
(510, 12, 2, '2'),
(511, 12, 3, '2'),
(512, 12, 4, '2'),
(513, 12, 5, '1'),
(514, 12, 6, '2'),
(515, 12, 9, '2'),
(516, 13, 1, '2'),
(517, 13, 2, '2'),
(518, 13, 3, '2'),
(519, 13, 4, '2'),
(520, 13, 5, '1'),
(521, 13, 6, '1'),
(522, 13, 9, '1'),
(523, 13, 10, 'Yes'),
(524, 13, 11, 'Yes'),
(525, 13, 12, 'Yes'),
(526, 14, 1, '1'),
(527, 14, 2, '2'),
(528, 14, 3, '3'),
(529, 14, 4, '4'),
(530, 14, 5, '5'),
(531, 14, 6, '1'),
(532, 14, 9, '2'),
(533, 14, 11, 'Yes'),
(534, 15, 1, '5'),
(535, 15, 2, '1'),
(536, 15, 3, '1'),
(537, 15, 4, '1'),
(538, 15, 5, '1'),
(539, 15, 6, '1'),
(540, 15, 9, '1'),
(541, 15, 10, 'Yes'),
(542, 15, 11, 'Yes'),
(543, 15, 12, 'Yes'),
(554, 17, 1, '1'),
(555, 17, 2, '1'),
(556, 17, 3, '1'),
(557, 17, 4, '1'),
(558, 17, 5, '1'),
(559, 17, 6, '1'),
(560, 17, 9, '1'),
(561, 17, 10, 'Yes'),
(562, 17, 11, 'Yes'),
(563, 17, 12, 'Yes'),
(572, 18, 1, '7'),
(573, 18, 2, '5'),
(574, 18, 3, '6'),
(575, 18, 4, '5'),
(576, 18, 5, '2'),
(577, 18, 6, '2'),
(578, 18, 9, '2'),
(579, 18, 10, 'Yes'),
(580, 19, 1, '5'),
(581, 19, 2, '5'),
(582, 19, 3, '5'),
(583, 19, 4, '5'),
(584, 19, 5, '5'),
(585, 19, 6, '2'),
(586, 19, 9, '2'),
(587, 19, 10, 'Yes'),
(588, 19, 11, 'Yes'),
(589, 19, 12, 'Yes'),
(590, 20, 1, '5'),
(591, 20, 2, '5'),
(592, 20, 3, '5'),
(593, 20, 4, '5'),
(594, 20, 5, '5'),
(595, 20, 6, '2'),
(596, 20, 9, '2'),
(597, 20, 10, 'Yes'),
(598, 20, 11, 'Yes'),
(599, 20, 12, 'Yes'),
(600, 21, 1, '5'),
(601, 21, 2, '5'),
(602, 21, 3, '5'),
(603, 21, 4, '5'),
(604, 21, 5, '5'),
(605, 21, 6, '2'),
(606, 21, 9, '2'),
(607, 21, 10, 'Yes'),
(608, 21, 11, 'Yes'),
(609, 21, 12, 'Yes'),
(630, 23, 1, '1'),
(631, 23, 2, '1'),
(632, 23, 3, '2'),
(633, 23, 4, '1'),
(634, 23, 5, '1'),
(635, 23, 6, '2'),
(636, 23, 9, '2'),
(637, 23, 10, 'Yes'),
(638, 23, 11, 'Yes'),
(639, 23, 12, 'Yes'),
(640, 24, 1, '1'),
(641, 24, 2, '2'),
(642, 24, 3, '1'),
(643, 24, 4, '2'),
(644, 24, 5, '1'),
(645, 24, 8, 'Yes'),
(646, 24, 13, '1'),
(647, 24, 14, '6'),
(648, 24, 15, 'Sukhumvit'),
(649, 24, 16, 'No idea'),
(650, 24, 17, 'No Idea'),
(651, 25, 1, '2'),
(652, 25, 2, '2'),
(653, 25, 3, '2'),
(654, 25, 4, '2'),
(655, 25, 5, '2'),
(656, 25, 8, 'Yes'),
(657, 25, 13, '2'),
(658, 25, 14, '2'),
(659, 25, 15, '100'),
(660, 25, 16, 'sss1123334333'),
(661, 25, 17, '0'),
(662, 26, 1, '4'),
(663, 26, 2, '3'),
(664, 26, 3, '4'),
(665, 26, 4, '1'),
(666, 26, 5, '1'),
(667, 26, 6, '4'),
(668, 26, 9, '3'),
(669, 27, 1, '3'),
(670, 27, 2, '2'),
(671, 27, 3, '3'),
(672, 27, 4, '2'),
(673, 27, 5, '1'),
(674, 27, 6, '3'),
(675, 27, 9, '1'),
(676, 27, 10, 'Yes'),
(677, 27, 11, 'Yes'),
(678, 27, 12, 'Yes'),
(691, 16, 1, '2'),
(692, 16, 2, '2'),
(693, 16, 3, '2'),
(694, 16, 4, '2'),
(695, 16, 5, '1'),
(696, 16, 6, '2'),
(697, 16, 9, '2'),
(698, 16, 10, 'Yes'),
(699, 16, 11, 'Yes'),
(700, 16, 12, 'Yes'),
(731, 22, 1, '1'),
(732, 22, 2, '1'),
(733, 22, 3, '1'),
(734, 22, 4, '1'),
(735, 22, 5, '1'),
(736, 22, 13, '1'),
(737, 22, 14, '1'),
(738, 22, 15, '1000'),
(739, 22, 16, '1000'),
(740, 22, 17, '1000'),
(742, 29, 21, '2'),
(801, 5, 1, '1'),
(802, 5, 2, '1'),
(803, 5, 3, '1'),
(804, 5, 4, '1'),
(805, 5, 5, '1'),
(806, 5, 13, '1'),
(807, 5, 14, '1'),
(808, 5, 15, '300'),
(809, 5, 16, '200'),
(810, 5, 17, '100'),
(811, 30, 1, '3'),
(812, 30, 2, '2'),
(813, 30, 3, '2'),
(814, 30, 4, '2'),
(815, 30, 5, '1'),
(816, 30, 6, '4'),
(817, 30, 9, '3'),
(818, 30, 10, 'Yes'),
(819, 30, 12, 'Yes'),
(820, 28, 6, '3'),
(832, 31, 1, '3'),
(833, 31, 2, '3'),
(834, 31, 3, '2'),
(835, 31, 4, '1'),
(836, 31, 5, '1'),
(837, 31, 13, '5'),
(838, 31, 14, '6'),
(839, 31, 15, '1200'),
(840, 31, 16, '1149'),
(841, 31, 17, '1130'),
(842, 31, 8, 'Yes'),
(843, 32, 1, '7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ac_packages`
--
ALTER TABLE `ac_packages`
 ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `ac_permissions`
--
ALTER TABLE `ac_permissions`
 ADD PRIMARY KEY (`permission_id`), ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `ac_roles`
--
ALTER TABLE `ac_roles`
 ADD PRIMARY KEY (`role_id`), ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `ac_role_permissions`
--
ALTER TABLE `ac_role_permissions`
 ADD PRIMARY KEY (`role_permission_id`), ADD KEY `role_id` (`role_id`,`permission_id`), ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `ac_users`
--
ALTER TABLE `ac_users`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `ac_user_packages`
--
ALTER TABLE `ac_user_packages`
 ADD PRIMARY KEY (`user_package_id`), ADD KEY `user_id` (`user_id`,`package_id`), ADD KEY `package_id` (`package_id`);

--
-- Indexes for table `ac_user_roles`
--
ALTER TABLE `ac_user_roles`
 ADD PRIMARY KEY (`user_role_id`), ADD KEY `user_id` (`user_id`,`role_id`), ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `ad_advertisements`
--
ALTER TABLE `ad_advertisements`
 ADD PRIMARY KEY (`advertisement_id`);

--
-- Indexes for table `ad_packages`
--
ALTER TABLE `ad_packages`
 ADD PRIMARY KEY (`ad_package_id`), ADD KEY `ad_type` (`ad_type`), ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `ad_payment`
--
ALTER TABLE `ad_payment`
 ADD PRIMARY KEY (`payment_id`), ADD KEY `advetisement_id` (`advetisement_id`);

--
-- Indexes for table `ad_recommendations`
--
ALTER TABLE `ad_recommendations`
 ADD PRIMARY KEY (`recommendation_id`);

--
-- Indexes for table `ll_documents`
--
ALTER TABLE `ll_documents`
 ADD PRIMARY KEY (`document_id`), ADD KEY `tenancy_id` (`document_head_id`);

--
-- Indexes for table `ll_document_heads`
--
ALTER TABLE `ll_document_heads`
 ADD PRIMARY KEY (`document_head_id`);

--
-- Indexes for table `ll_tenancy`
--
ALTER TABLE `ll_tenancy`
 ADD PRIMARY KEY (`tenancy_id`), ADD KEY `property_id` (`property_id`,`tenant_id`);

--
-- Indexes for table `ll_tenants`
--
ALTER TABLE `ll_tenants`
 ADD PRIMARY KEY (`tenant_id`);

--
-- Indexes for table `ll_transactions`
--
ALTER TABLE `ll_transactions`
 ADD PRIMARY KEY (`transaction_id`), ADD KEY `tenancy_id` (`tenancy_id`,`transaction_head_id`,`vendor_id`);

--
-- Indexes for table `ll_transaction_heads`
--
ALTER TABLE `ll_transaction_heads`
 ADD PRIMARY KEY (`transaction_head_id`);

--
-- Indexes for table `ll_vendors`
--
ALTER TABLE `ll_vendors`
 ADD PRIMARY KEY (`vendor_id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pr_amenities`
--
ALTER TABLE `pr_amenities`
 ADD PRIMARY KEY (`amenity_id`);

--
-- Indexes for table `pr_attributes`
--
ALTER TABLE `pr_attributes`
 ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `pr_deals`
--
ALTER TABLE `pr_deals`
 ADD PRIMARY KEY (`deal_id`);

--
-- Indexes for table `pr_groups`
--
ALTER TABLE `pr_groups`
 ADD PRIMARY KEY (`group_id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `pr_locations`
--
ALTER TABLE `pr_locations`
 ADD PRIMARY KEY (`location_id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `pr_location_transports`
--
ALTER TABLE `pr_location_transports`
 ADD PRIMARY KEY (`transport_id`), ADD KEY `parent_id` (`parent_id`,`location_id`);

--
-- Indexes for table `pr_media`
--
ALTER TABLE `pr_media`
 ADD PRIMARY KEY (`media_id`), ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `pr_properties`
--
ALTER TABLE `pr_properties`
 ADD PRIMARY KEY (`property_id`), ADD KEY `user_id` (`user_id`,`deal_id`,`type_id`), ADD KEY `deal_id` (`deal_id`), ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `pr_property_amenities`
--
ALTER TABLE `pr_property_amenities`
 ADD PRIMARY KEY (`property_amenity_id`);

--
-- Indexes for table `pr_property_transport`
--
ALTER TABLE `pr_property_transport`
 ADD PRIMARY KEY (`id`), ADD KEY `property_id` (`property_id`,`transport_id`);

--
-- Indexes for table `pr_relations`
--
ALTER TABLE `pr_relations`
 ADD PRIMARY KEY (`relation_id`), ADD KEY `type_id` (`type_id`,`group_id`), ADD KEY `group_id` (`group_id`), ADD KEY `attribute_id` (`attribute_id`), ADD KEY `deal_id` (`deal_id`);

--
-- Indexes for table `pr_types`
--
ALTER TABLE `pr_types`
 ADD PRIMARY KEY (`type_id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `pr_values`
--
ALTER TABLE `pr_values`
 ADD PRIMARY KEY (`value_id`), ADD KEY `attribute_id` (`attribute_id`), ADD KEY `property_id` (`property_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ac_packages`
--
ALTER TABLE `ac_packages`
MODIFY `package_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ac_permissions`
--
ALTER TABLE `ac_permissions`
MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ac_roles`
--
ALTER TABLE `ac_roles`
MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ac_role_permissions`
--
ALTER TABLE `ac_role_permissions`
MODIFY `role_permission_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ac_users`
--
ALTER TABLE `ac_users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `ac_user_packages`
--
ALTER TABLE `ac_user_packages`
MODIFY `user_package_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ac_user_roles`
--
ALTER TABLE `ac_user_roles`
MODIFY `user_role_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ad_advertisements`
--
ALTER TABLE `ad_advertisements`
MODIFY `advertisement_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `ad_packages`
--
ALTER TABLE `ad_packages`
MODIFY `ad_package_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `ad_payment`
--
ALTER TABLE `ad_payment`
MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `ad_recommendations`
--
ALTER TABLE `ad_recommendations`
MODIFY `recommendation_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `ll_documents`
--
ALTER TABLE `ll_documents`
MODIFY `document_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `ll_document_heads`
--
ALTER TABLE `ll_document_heads`
MODIFY `document_head_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ll_tenancy`
--
ALTER TABLE `ll_tenancy`
MODIFY `tenancy_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `ll_tenants`
--
ALTER TABLE `ll_tenants`
MODIFY `tenant_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `ll_transactions`
--
ALTER TABLE `ll_transactions`
MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `ll_transaction_heads`
--
ALTER TABLE `ll_transaction_heads`
MODIFY `transaction_head_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ll_vendors`
--
ALTER TABLE `ll_vendors`
MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pr_amenities`
--
ALTER TABLE `pr_amenities`
MODIFY `amenity_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pr_attributes`
--
ALTER TABLE `pr_attributes`
MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `pr_deals`
--
ALTER TABLE `pr_deals`
MODIFY `deal_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pr_groups`
--
ALTER TABLE `pr_groups`
MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pr_locations`
--
ALTER TABLE `pr_locations`
MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `pr_location_transports`
--
ALTER TABLE `pr_location_transports`
MODIFY `transport_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT for table `pr_media`
--
ALTER TABLE `pr_media`
MODIFY `media_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `pr_properties`
--
ALTER TABLE `pr_properties`
MODIFY `property_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `pr_property_amenities`
--
ALTER TABLE `pr_property_amenities`
MODIFY `property_amenity_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `pr_property_transport`
--
ALTER TABLE `pr_property_transport`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=218;
--
-- AUTO_INCREMENT for table `pr_relations`
--
ALTER TABLE `pr_relations`
MODIFY `relation_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `pr_types`
--
ALTER TABLE `pr_types`
MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `pr_values`
--
ALTER TABLE `pr_values`
MODIFY `value_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=844;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ac_role_permissions`
--
ALTER TABLE `ac_role_permissions`
ADD CONSTRAINT `ac_role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `ac_permissions` (`permission_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `ac_role_permissions_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `ac_roles` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ac_user_packages`
--
ALTER TABLE `ac_user_packages`
ADD CONSTRAINT `ac_user_packages_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ac_packages` (`package_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ac_user_roles`
--
ALTER TABLE `ac_user_roles`
ADD CONSTRAINT `ac_user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `ac_roles` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ad_payment`
--
ALTER TABLE `ad_payment`
ADD CONSTRAINT `ad_payment_ibfk_1` FOREIGN KEY (`advetisement_id`) REFERENCES `ad_advertisements` (`advertisement_id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
