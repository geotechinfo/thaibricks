//on document load
    $(function(){
			   
		//window height and scroll	   
		$(window).load(function(){ // On load
			$('.leftMenuNav').css({'min-height':(($(window).height()))});
			$('.rightContentWrap').css({'min-height':(($(window).height()))});
			//$('.inner').css({'min-height':(($(window).height()) - 40)});
			
			$('.leftMenuNav').css({'max-height':(($(window).height()))});
			$('.rightContentWrap').css({'max-height':(($(window).height()))});
			//$('.inner').css({'max-height':(($(window).height()) - 40)});
			$('.inner').css('min-height', '570px' );
		});
		
		//left menu active class
		$('.sellermenu li').click(function(){
	        $(this).siblings().removeClass("active");
			$(this).addClass("active");
		});
	
		
		//disable link
		/*
		$('.disabledproperty a.btn-block', '.disabledproperty .addpropertyname a').click(function(e){
	        e.preventDefault();
		});
		*/
		
    });
	
// Steps Begin
	$(function($) {
			
			$(document).ready(function() {
			$("#step1").siblings().hide();
			$('.stepwrap a').on('click', function(e)  {
				var currentAttrValue = jQuery(this).attr('href');
		 
				// Show/Hide Tabs
				jQuery('.steps ' + currentAttrValue).show().siblings().hide();
		 
				// Change/remove current tab to active
				 $(this).addClass('active').siblings().removeClass('active');
		 
				e.preventDefault();
				});
			});
	});
	
// Steps End

// Multiple Select
$(function($){			
	$(document).ready(function() {
		$(".js-example-placeholder-multiple").select2({
		placeholder: "Select SubLocation"
		});
		
		$(".js-example-placeholder-multiple-furnituretype").select2({
		placeholder: "Select Furniture Type"
		});
		
		$(".js-example-placeholder-multiple-clocation").select2({
		placeholder: "Select Commercial SubLocation"
		});
		
		$(".js-example-placeholder-multiple-cfurnituretype").select2({
		placeholder: "Select Commercial Furniture Type"
		});
	});
});	
// Multiple Select
	